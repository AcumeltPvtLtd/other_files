import React from 'react';

export interface FeatureCardProps {
  title: string;
  desc: string;
  image: string;
  icon: React.ReactNode;
  index: number;
  key?: string | number;
}

export interface GradeRow {
  grade: string;
  tensile: string | number;
  yield: string | number;
  elongation: string | number;
}

export interface SiMoGradeRow extends GradeRow {
  si: string | number;
  mo: string | number;
}
