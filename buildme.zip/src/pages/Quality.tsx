import React from 'react';
import { motion } from 'motion/react';
import { ShieldCheck, Microscope, FlaskConical, Ruler, Activity, CheckCircle2 } from 'lucide-react';
import { SectionHeading } from '../components/Layout';

const Quality = () => {
  const foundryEquipment = [
    {
      title: 'Chemical Analysis',
      subtitle: 'Ametek SpectroMaxX',
      icon: <FlaskConical className="w-8 h-8" />,
      image: 'https://acumelt.com/wp-content/uploads/2024/04/Spectrometer-image-1.webp',
      specs: [
        { label: 'Elements', value: '24 Elements' },
        { label: 'Range', value: 'Wavelength Range 120-670 nm' },
        { label: 'Calibration', value: 'Easy auto calibration of equipment' },
        { label: 'Diagnosis', value: 'Auto fault diagnosis system' },
        { label: 'Cooling', value: 'Auto optical cooling' }
      ]
    },
    {
      title: 'Microstructure Analysis',
      subtitle: 'Olympus GX53F Microscope',
      icon: <Microscope className="w-8 h-8" />,
      image: 'https://acumelt.com/wp-content/uploads/2024/04/Microscope-image-1.webp',
      specs: [
        { label: 'Image Analysis', value: 'Computerized, cast iron module' },
        { label: 'Nodule count', value: 'Count, Flask size, type, distribution' },
        { label: 'Distribution', value: 'Pearlite/Ferrite distribution' },
        { label: 'Imaging', value: 'EFI Extended Focal Imaging' },
        { label: 'Resolution', value: 'Multi-plane image stitching' }
      ]
    },
    {
      title: 'Sand Testing',
      subtitle: 'Versatile Sand Testing Equipment',
      icon: <Activity className="w-8 h-8" />,
      image: 'https://acumelt.com/wp-content/uploads/2024/04/sand-testing-equipment-image-1.webp',
      specs: [
        { label: 'Capabilities', value: 'Compactibility, Moisture, Permeability' },
        { label: 'Universal Strength', value: 'Tensile, Compressibility, Shear' },
        { label: 'Green Strength', value: 'Green Compression Strength' },
        { label: 'Hardness', value: 'Core Hardness, Mold Hardness' },
        { label: 'Distribution', value: 'Grain Size Distribution' },
        { label: 'Specialized', value: 'Wet/Hot Tensile, Flowability' }
      ]
    },
    {
      title: 'Universal Testing Machine',
      subtitle: 'UTES HGFL 40',
      icon: <Activity className="w-8 h-8" />,
      image: 'https://acumelt.com/wp-content/uploads/2024/04/physical-testing-equipment-image-1.webp',
      specs: [
        { label: 'Capacity', value: '400 kN' },
        { label: 'Control', value: 'Computerized with data acquisition' },
        { label: 'Extensometer', value: 'Model: EE-2 (25mm, 50mm, 70mm)' },
        { label: 'Tests', value: 'Tensile, Compression, Transverse, Bend' },
        { label: 'Accuracy', value: 'Class 1 as per ISO 7500-1' }
      ]
    },
    {
      title: 'Brinell Hardness Tester',
      subtitle: 'FIE Model: B 3000-PC',
      icon: <Ruler className="w-8 h-8" />,
      image: 'https://picsum.photos/seed/brinell/800/600',
      specs: [
        { label: 'Test Loads', value: '500 kgf to 3000 kgf' },
        { label: 'Indenter', value: '5mm & 10mm Tungsten Carbide Ball' },
        { label: 'Measurement', value: 'Optical microscope with digital readout' },
        { label: 'Standards', value: 'ASTM E10 / ISO 6506' }
      ]
    },
    {
      title: 'Ultrasonic Testing',
      subtitle: 'Modosonic Instruments (ARJUN 30)',
      icon: <ShieldCheck className="w-8 h-8" />,
      image: 'https://acumelt.com/wp-content/uploads/2024/04/ultrasonic-testing-image-1.webp',
      specs: [
        { label: 'Test Range', value: '2.5mm to 10 meter' },
        { label: 'Velocity', value: '1000 to 15000 met/sec' },
        { label: 'Rectification', value: 'Full-wave rectified with filtering' },
        { label: 'Frequency', value: 'Broad Band 0.5 MHz to 15Mhz' },
        { label: 'Linearity', value: 'V: +3%, H: +0.5%' }
      ]
    },
    {
      title: 'Magnetic Particle Inspection',
      subtitle: 'Yoke Type MPI Machine',
      icon: <ShieldCheck className="w-8 h-8" />,
      image: 'https://picsum.photos/seed/mpi/800/600',
      specs: [
        { label: 'Equipment', value: 'AC/DC Magnetic Yoke' },
        { label: 'Detection', value: 'Surface & Sub-surface cracks' },
        { label: 'Method', value: 'Dry & Wet Fluorescent' },
        { label: 'Portability', value: 'Handheld for field inspection' },
        { label: 'Standards', value: 'ASTM E1444 / ISO 9934' }
      ]
    },
    {
      title: 'Impact Testing',
      subtitle: 'FIE Charpy Impact Tester',
      icon: <Activity className="w-8 h-8" />,
      image: 'https://picsum.photos/seed/impact/800/600',
      specs: [
        { label: 'Equipment', value: 'FIE Impact Testing Machine' },
        { label: 'Energy Range', value: '0-300 Joules' },
        { label: 'Test Type', value: 'Charpy V-Notch / Izod' },
        { label: 'Accuracy', value: 'High precision pendulum system' },
        { label: 'Standards', value: 'ASTM E23 / ISO 148-1' }
      ]
    }
  ];

  const machineShopEquipment = [
    {
      title: 'CNC CMM',
      subtitle: 'CRYSTA Apex V 7106 PH10MQ SP25',
      icon: <Ruler className="w-8 h-8" />,
      image: 'https://acumelt.com/wp-content/uploads/2024/04/cmm-image-1.webp',
      specs: [
        { label: 'Range (X/Y/Z)', value: '700 x 1000 x 600 mm' },
        { label: 'Resolution', value: '0.1 µm' },
        { label: 'Accuracy', value: '(1.7+3 L/1000)µm (ISO10360-2)' },
        { label: 'Repeatability', value: '1.3µm' },
        { label: 'Temp Comp', value: '16° to 26°C range' },
        { label: 'Performance', value: '519 mm/s Speed, 2309 mm/s² Accel' }
      ]
    },
    {
      title: 'Contour Measurement',
      subtitle: 'Contracer CV2100 M4',
      icon: <Activity className="w-8 h-8" />,
      image: 'https://picsum.photos/seed/contour/800/600',
      specs: [
        { label: 'Measuring Range', value: 'X: 100mm, Z1: 50mm' },
        { label: 'Column Travel', value: '350mm Vertical' },
        { label: 'Linear Accuracy', value: '2.5μm/100mm' },
        { label: 'Resolution', value: '0.1μm (X & Z1)' },
        { label: 'X Accuracy', value: '±(2.5 + 0.02L)µm' },
        { label: 'Z1 Accuracy', value: '±(2.5 + |0.1H|)µm' }
      ]
    },
    {
      title: 'Surface Roughness',
      subtitle: 'Surftest SJ 220 (4mN)',
      icon: <CheckCircle2 className="w-8 h-8" />,
      image: 'https://picsum.photos/seed/roughness/800/600',
      specs: [
        { label: 'Measuring Range', value: 'X: 17.5mm, Z: 360 µm' },
        { label: 'Resolution', value: '0.0002µm (min)' },
        { label: 'Stylus', value: '90°/ 5µm; 4mN force' },
        { label: 'Standards', value: 'ISO 4287, ISO 13565, ISO 21920' },
        { label: 'Profiles', value: 'Primary (P), Roughness (R), DF, R-Motif' },
        { label: 'Cut-off (λc)', value: '0.08 / 0.25 / 0.8 / 2.5 / 8 mm' }
      ]
    }
  ];

  const surfaceTreatmentEquipment = [
    {
      title: 'Surface Treatment Inspection',
      subtitle: 'Coating Quality Control',
      icon: <CheckCircle2 className="w-8 h-8" />,
      image: 'https://raw.githubusercontent.com/AcumeltPvtLtd/AcumeltPvtLtd.github.io/main/src/paint_shop.jpg',
      specs: [
        { label: 'Dry film thickness', value: 'Magnetic or eddy current coating thickness gauge' },
        { label: 'Adhesion of coating', value: 'Cross-cut adhesion test' },
        { label: 'Corrosion resistance', value: 'Neutral salt spray test' },
        { label: 'Hardness of coating', value: 'Pencil hardness test' },
        { label: 'Impact resistance', value: 'Falling weight impact test' },
        { label: 'Gloss level', value: 'Gloss meter measurement' },
        { label: 'Flexibility of coating', value: 'Mandrel bend test' },
        { label: 'Abrasion resistance', value: 'Taber abrasion test' },
        { label: 'Blistering of coating', value: 'Visual evaluation' },
        { label: 'Rusting after corrosion test', value: 'Visual evaluation' }
      ],
      footer: 'Standards followed: ISO 2808, ASTM D7091, ISO 2409, ASTM D3359, ASTM B117, ISO 9227, ASTM D3363, ISO 15184, ASTM D2794, ISO 6272, ASTM D523, ISO 2813, ASTM D522, ISO 6860, ASTM D4060, ISO 7784, ASTM D714, ASTM D610'
    }
  ];

  const QualityCard = ({ item, idx }: { item: any, idx: number, key?: React.Key }) => (
    <motion.div 
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: idx * 0.1 }}
      className="group bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-[3rem] overflow-hidden hover:border-brand-orange/30 transition-all duration-500"
    >
      <div className="flex flex-col md:flex-row h-full">
        <div className="md:w-1/2 relative overflow-hidden min-h-[300px]">
          <img 
            src={item.image} 
            alt={item.title} 
            className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110 opacity-100 dark:opacity-90"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-transparent" />
          <div className="absolute inset-0 bg-gradient-to-r from-transparent to-transparent dark:to-zinc-900 hidden md:block" />
        </div>
        <div className="md:w-1/2 p-10 flex flex-col justify-between">
          <div>
            <div className="text-brand-orange mb-6">{item.icon}</div>
            <h4 className="text-2xl font-bold text-zinc-950 dark:text-white mb-2">{item.title}</h4>
            <p className="text-zinc-500 dark:text-zinc-500 text-sm font-black uppercase tracking-widest mb-8">{item.subtitle}</p>
            <div className="space-y-4">
              {item.specs.map((spec: any) => (
                <div key={spec.label} className="flex justify-between items-start gap-4 text-sm border-b border-zinc-200 dark:border-zinc-800 pb-3">
                  <span className="text-zinc-500 dark:text-zinc-500 font-bold uppercase tracking-widest text-[10px] shrink-0 mt-0.5">{spec.label}</span>
                  <span className="text-zinc-800 dark:text-zinc-200 font-medium text-right leading-tight">{spec.value}</span>
                </div>
              ))}
            </div>
          </div>
          {item.footer && (
            <div className="mt-8 pt-6 border-t border-zinc-200 dark:border-zinc-800">
              <p className="text-[10px] text-zinc-500 dark:text-zinc-500 uppercase tracking-widest leading-relaxed">
                {item.footer}
              </p>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );

  return (
    <div className="pt-32 pb-20 bg-white dark:bg-zinc-950 transition-colors duration-300">
      <div className="container mx-auto px-6">
        <SectionHeading subtitle="Quality Control" title="Foundry & Heat Treatment" centered />
        <div className="grid lg:grid-cols-2 gap-12 mb-32">
          {foundryEquipment.map((item, idx) => (
            <QualityCard key={item.title} item={item} idx={idx} />
          ))}
        </div>

        <SectionHeading subtitle="Quality Control" title="Machine Shop" centered />
        <div className="grid lg:grid-cols-2 gap-12 mb-32">
          {machineShopEquipment.map((item, idx) => (
            <QualityCard key={item.title} item={item} idx={idx} />
          ))}
        </div>

        <SectionHeading subtitle="Quality Control" title="Surface Treatment" centered />
        <div className="grid lg:grid-cols-1 gap-12 mb-32">
          {surfaceTreatmentEquipment.map((item, idx) => (
            <QualityCard key={item.title} item={item} idx={idx} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default Quality;
