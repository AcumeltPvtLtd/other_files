import React from 'react';
import { motion } from 'motion/react';
import { Mail, Phone, MapPin, Send, Linkedin } from 'lucide-react';
import { SectionHeading, MoltenButton } from '../components/Layout';

const Contact = () => {
  return (
    <div className="pt-32 pb-20 bg-white dark:bg-zinc-950 transition-colors duration-300">
      <div className="container mx-auto px-6">
        <SectionHeading subtitle="Get in Touch" title="Contact Acumelt Pvt. Ltd." />
        
        <div className="grid lg:grid-cols-2 gap-20">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <p className="text-zinc-600 dark:text-zinc-400 text-xl font-light leading-relaxed mb-12">
              We are ready to discuss your casting needs. Reach out to us for technical inquiries, quotations, or facility visits.
            </p>
            
            <div className="space-y-10">
              <div className="flex gap-8 group">
                <div className="p-5 bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl text-brand-orange group-hover:bg-brand-orange group-hover:text-zinc-950 transition-all">
                  <Mail className="w-8 h-8" />
                </div>
                <div>
                  <h4 className="text-brand-orange font-black text-xs uppercase tracking-[0.3em] mb-2">Email Us</h4>
                  <a href="mailto:contact@acumelt.com" className="text-2xl font-bold text-zinc-950 dark:text-white hover:text-brand-orange transition-colors">contact@<span className="text-[#F37021]">acumelt</span>.com</a>
                </div>
              </div>
              
              <div className="flex gap-8 group">
                <div className="p-5 bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl text-brand-orange group-hover:bg-brand-orange group-hover:text-zinc-950 transition-all">
                  <Phone className="w-8 h-8" />
                </div>
                <div>
                  <h4 className="text-brand-orange font-black text-xs uppercase tracking-[0.3em] mb-2">Call Us</h4>
                  <a href="tel:+918160222587" className="text-2xl font-bold text-zinc-950 dark:text-white hover:text-brand-orange transition-colors">+91 81602 22587</a>
                </div>
              </div>
              
              <div className="flex gap-8 group">
                <div className="p-5 bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl text-brand-orange group-hover:bg-brand-orange group-hover:text-zinc-950 transition-all">
                  <MapPin className="w-8 h-8" />
                </div>
                <div>
                  <h4 className="text-brand-orange font-black text-xs uppercase tracking-[0.3em] mb-2">Factory Location</h4>
                  <p className="text-xl text-zinc-600 dark:text-zinc-400 font-light leading-relaxed">
                    Survey No. 434/435, Nr. Narmada Pumping Station,<br />
                    Rajkot Kalawad Highway, Village Nikava,<br />
                    Tk. Kalawad, Dist. Jamnagar 361162
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-16 pt-16 border-t border-zinc-100 dark:border-zinc-900">
              <h4 className="text-brand-orange font-black text-xs uppercase tracking-[0.3em] mb-8">Follow Our Progress</h4>
              <motion.a 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                href="https://www.linkedin.com/company/acumelt/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center gap-4 px-8 py-4 bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl text-zinc-950 dark:text-white font-bold hover:border-brand-orange transition-all"
              >
                <Linkedin className="w-6 h-6 text-brand-orange" />
                LinkedIn Profile
              </motion.a>
            </div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 p-12 rounded-[4rem] relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-96 h-96 bg-brand-orange/5 blur-[120px]" />
            <form className="relative z-10 space-y-8" onSubmit={(e) => e.preventDefault()}>
              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-3">
                  <label className="text-xs font-black text-zinc-400 dark:text-zinc-500 uppercase tracking-widest ml-4">Full Name</label>
                  <input 
                    type="text" 
                    placeholder="John Doe"
                    className="w-full bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-2xl px-6 py-4 text-zinc-950 dark:text-white focus:outline-none focus:border-brand-orange transition-all"
                  />
                </div>
                <div className="space-y-3">
                  <label className="text-xs font-black text-zinc-400 dark:text-zinc-500 uppercase tracking-widest ml-4">Email Address</label>
                  <input 
                    type="email" 
                    placeholder="john@example.com"
                    className="w-full bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-2xl px-6 py-4 text-zinc-950 dark:text-white focus:outline-none focus:border-brand-orange transition-all"
                  />
                </div>
              </div>
              
              <div className="space-y-3">
                <label className="text-xs font-black text-zinc-400 dark:text-zinc-500 uppercase tracking-widest ml-4">Subject</label>
                <input 
                  type="text" 
                  placeholder="Inquiry about Ductile Iron Castings"
                  className="w-full bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-2xl px-6 py-4 text-zinc-950 dark:text-white focus:outline-none focus:border-brand-orange transition-all"
                />
              </div>
              
              <div className="space-y-3">
                <label className="text-xs font-black text-zinc-400 dark:text-zinc-500 uppercase tracking-widest ml-4">Your Message</label>
                <textarea 
                  rows={6}
                  placeholder="Tell us about your project requirements..."
                  className="w-full bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-2xl px-6 py-4 text-zinc-950 dark:text-white focus:outline-none focus:border-brand-orange transition-all resize-none"
                />
              </div>
              
              <button className="w-full relative px-8 py-5 font-black rounded-2xl bg-brand-orange text-zinc-950 flex items-center justify-center gap-3 overflow-hidden group transition-all hover:shadow-[0_0_30px_rgba(249,164,49,0.4)]">
                <span className="relative z-10 flex items-center gap-3">
                  SEND MESSAGE <Send className="w-5 h-5" />
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
              </button>
            </form>
          </motion.div>
        </div>

        <div className="mt-32 rounded-[4rem] overflow-hidden border border-zinc-200 dark:border-zinc-800 h-[500px] relative">
          <div className="absolute inset-0 bg-zinc-50 dark:bg-zinc-900 flex items-center justify-center">
            <div className="text-center">
              <MapPin className="w-16 h-16 text-brand-orange mx-auto mb-6 opacity-50" />
              <p className="text-zinc-400 dark:text-zinc-500 font-black text-xs uppercase tracking-[0.4em]">Interactive Map Placeholder</p>
              <p className="text-zinc-500 dark:text-zinc-600 mt-2 text-sm">Village Nikava, Rajkot Kalawad Highway</p>
            </div>
          </div>
          {/* Real map iframe could go here */}
        </div>
      </div>
    </div>
  );
};

export default Contact;
