import React from 'react';
import { motion } from 'motion/react';
import { Layers, Database, Globe, Briefcase } from 'lucide-react';
import { SectionHeading } from '../components/Layout';

const Products = () => {
  return (
    <div className="pt-32 pb-20 bg-white dark:bg-zinc-950 transition-colors duration-300">
      <div className="container mx-auto px-6">
        <SectionHeading subtitle="Market Presence" title="Customer Segments" centered />
        <div className="grid md:grid-cols-3 gap-8">
          {[
            { title: 'Automotive', icon: <Globe className="w-8 h-8" />, desc: 'Chassis, suspension, and engine components for passenger and commercial vehicles.' },
            { title: 'Agriculture', icon: <Briefcase className="w-8 h-8" />, desc: 'Tractor parts, plow components, and irrigation system castings.' },
            { title: 'Infrastructure', icon: <Globe className="w-8 h-8" />, desc: 'Pipes, valves, and heavy-duty fittings for large-scale construction projects.' }
          ].map((item, idx) => (
            <motion.div 
              key={item.title}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="p-12 bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-[3rem] group hover:border-brand-orange/30 transition-all text-center"
            >
              <div className="p-5 bg-brand-orange/10 rounded-2xl w-fit text-brand-orange mb-8 mx-auto group-hover:bg-brand-orange group-hover:text-zinc-950 transition-all">
                {item.icon}
              </div>
              <h4 className="text-2xl font-bold text-zinc-950 dark:text-white mb-4">{item.title}</h4>
              <p className="text-zinc-600 dark:text-zinc-400 text-lg font-light leading-relaxed">{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Products;
