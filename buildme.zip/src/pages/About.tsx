import React from 'react';
import { motion } from 'motion/react';
import { Target, Eye, Map, Factory, AlertTriangle, CheckCircle2, ArrowRight, ArrowDown } from 'lucide-react';
import { SectionHeading } from '../components/Layout';

const About = () => {
  return (
    <div className="pt-32 pb-20 bg-white dark:bg-zinc-950 transition-colors duration-300">
      <div className="container mx-auto px-6">
        <SectionHeading subtitle="Company Profile" title="About Acumelt Pvt. Ltd." />
        
        <div className="grid lg:grid-cols-2 gap-20 mb-32">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-8 text-zinc-600 dark:text-zinc-400 text-lg font-light leading-relaxed"
          >
            <p className="text-justify">
              Acumelt Private Limited manufactures ductile iron components designed for demanding engineering applications, with a focus on metallurgical control, dimensional accuracy, and consistent product quality.
            </p>
            <p className="text-justify">
              The facility operates a fully integrated process chain including casting, machining, heat treatment, and surface finishing such as liquid painting and powder coating.
            </p>
            <p className="text-justify">
             Consolidating these processes in-house enables tighter process control, improved traceability, reduced handling and logistics, and optimized production efficiency, resulting in improved reliability and cost effectiveness for the end customer.
            </p>

            <p className="text-justify">
             Acumelt is endowded with numerous resources such as state of the art physical infrastructure & highly experienced and capable personnel.
            </p>
            <ul className="space-y-4 pt-6">
              <li className="flex items-center gap-4 text-zinc-950 dark:text-white font-bold">
                <CheckCircle2 className="text-brand-orange w-6 h-6" />
                Casting 
              </li>
              <li className="flex items-center gap-4 text-zinc-950 dark:text-white font-bold">
                <CheckCircle2 className="text-brand-orange w-6 h-6" />
                Machining
              </li>
              <li className="flex items-center gap-4 text-zinc-950 dark:text-white font-bold">
                <CheckCircle2 className="text-brand-orange w-6 h-6" />
                Heat Treatment
              </li>
              <li className="flex items-center gap-4 text-zinc-950 dark:text-white font-bold">
                <CheckCircle2 className="text-brand-orange w-6 h-6" />
                Surface Treatment 
              </li>
            </ul>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="bg-zinc-50 dark:bg-zinc-900/50 border border-zinc-200 dark:border-zinc-800 p-12 rounded-[3rem] relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-64 h-64 bg-brand-orange/5 blur-[100px]" />
            <h4 className="text-brand-orange font-black text-xs uppercase tracking-[0.3em] mb-12">Capacity Breakdown</h4>
            <div className="space-y-10">
              {[
                { label: 'Installed Capacity', value: '12,000 Tons', color: 'bg-zinc-200 dark:bg-zinc-800' },
                { label: 'Utilized Capacity', value: '5,000 Tons', color: 'bg-brand-orange/20' },
                
                { label: 'Total Free for Business', value: '7,000 Tons', color: 'bg-brand-orange' },
              ].map((item, idx) => (
                <div key={item.label} className="relative">
                  <div className="flex justify-between items-end mb-3">
                    <span className="text-zinc-500 dark:text-zinc-400 font-bold uppercase text-xs tracking-widest">{item.label}</span>
                    <span className="text-zinc-950 dark:text-white font-black text-xl">{item.value}</span>
                  </div>
                  <div className="h-2 w-full bg-zinc-200 dark:bg-zinc-800 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      whileInView={{ width: '100%' }}
                      viewport={{ once: true }}
                      transition={{ delay: idx * 0.1, duration: 1 }}
                      className={`h-full ${item.color}`}
                    />
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        <div className="grid md:grid-cols-2 gap-12 mb-32">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="p-12 bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-[3rem] group hover:border-brand-orange/30 transition-all"
          >
            <div className="p-5 bg-brand-orange/10 rounded-2xl w-fit text-brand-orange mb-8 group-hover:bg-brand-orange group-hover:text-zinc-950 transition-all">
              <Eye className="w-10 h-10" />
            </div>
            <h4 className="text-3xl font-bold text-zinc-950 dark:text-white mb-6">Vision Statement</h4>
            <p className="text-zinc-600 dark:text-zinc-400 text-lg font-light leading-relaxed text-justify">
              To be a globally respected manufacturer of ductile iron cast components, driven by innovation, automation, and sustainable practices—where efficiency, safety, and technological excellence define every aspect of production.
            </p>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="p-12 bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-[3rem] group hover:border-brand-orange/30 transition-all"
          >
            <div className="p-5 bg-brand-orange/10 rounded-2xl w-fit text-brand-orange mb-8 group-hover:bg-brand-orange group-hover:text-zinc-950 transition-all">
              <Target className="w-10 h-10" />
            </div>
            <h4 className="text-3xl font-bold text-zinc-950 dark:text-white mb-6">Mission Statement</h4>
            <p className="text-zinc-600 dark:text-zinc-400 text-lg font-light leading-relaxed text-justify">
              To deliver high-quality, reliable, and competitive ductile iron cast components through continuous improvement and responsible growth. We strive to set industry benchmarks, build long-term partnerships, and create a smarter, safer, and more sustainable manufacturing ecosystem.
            </p>
          </motion.div>
        </div>

        <div className="mb-32 text-center">
          <SectionHeading subtitle="Certifications" title="Global Standards" centered />
          <div className="flex flex-wrap justify-center gap-12">
            {[
              { name: 'IATF 16949', desc: 'Automotive Quality Management' },
              { name: 'ISO 9001', desc: 'Quality Management Systems' },
              { name: 'ISO 14001', desc: 'Environmental Management' }
            ].map(cert => (
              <div key={cert.name} className="p-10 bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-[2.5rem] w-64 group hover:border-brand-orange/30 transition-all">
                <div className="text-brand-orange font-black text-2xl mb-4">{cert.name}</div>
                <div className="text-zinc-500 text-xs font-black uppercase tracking-widest">{cert.desc}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="mb-32">
          <SectionHeading subtitle="Infrastructure" title="Land Use & Facility" centered />
          <div className="grid md:grid-cols-2 gap-12">
            <div className="relative aspect-video rounded-[3rem] overflow-hidden border border-zinc-200 dark:border-zinc-800">
              <img 
                src="https://acumelt.com/wp-content/uploads/2024/04/melting-image-01.webp" 
                alt="Factory" 
                className="w-full h-full object-cover opacity-100 dark:opacity-90"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-transparent" />
              <div className="absolute inset-0 bg-gradient-to-t from-transparent dark:from-zinc-950 to-transparent" />
              <div className="absolute bottom-12 left-12">
                <div className="text-brand-orange font-black text-6xl mb-2">41,300 <span className="text-2xl">m²</span></div>
                <div className="text-zinc-950 dark:text-white font-black text-xs uppercase tracking-[0.3em]">Total Land Area</div>
              </div>
            </div>
            <div className="relative aspect-video rounded-[3rem] overflow-hidden border border-zinc-200 dark:border-zinc-800">
              <img 
                src="https://acumelt.com/wp-content/uploads/2024/04/pauring-system-image-1.webp" 
                alt="Factory Floor" 
                className="w-full h-full object-cover opacity-100 dark:opacity-90"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-transparent" />
              <div className="absolute inset-0 bg-gradient-to-t from-transparent dark:from-zinc-950 to-transparent" />
              <div className="absolute bottom-12 left-12">
                <div className="text-brand-orange font-black text-6xl mb-2">8,000 <span className="text-2xl">m²</span></div>
                <div className="text-zinc-950 dark:text-white font-black text-xs uppercase tracking-[0.3em]">Factory Floor Area</div>
              </div>
            </div>
          </div>
        </div>

        <div className="mb-32">
          <SectionHeading subtitle="The Challenge" title="Solving Foundry Inefficiencies" centered />
          <div className="grid md:grid-cols-3 gap-8 items-start">
            {[
              {
                title: 'Jobbing Foundries',
                icon: <AlertTriangle className="w-8 h-8" />,
                points: ['Myopic production planning', 'Suboptimal plant design', 'High rejection rates'],
                solutions: ['Strategic production planning', 'Optimized plant layout', 'Quality control systems']
              },
              {
                title: 'Man Oriented Processes',
                icon: <AlertTriangle className="w-8 h-8" />,
                points: ['High switchover time', 'High overheads per kg', 'Inconsistent quality'],
                solutions: ['Automated switchover systems', 'Reduced overheads', 'Standardized quality']
              },
              {
                title: 'Lack of Automation',
                icon: <AlertTriangle className="w-8 h-8" />,
                points: ['Unutilized capacity', 'Frequent breakdowns', 'High cost of production'],
                solutions: ['Full capacity utilization', 'Predictive maintenance', 'Cost-effective automation']
              }
            ].map((item, idx) => (
              <div key={item.title} className="flex flex-col items-center">
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  className="p-10 bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-[2.5rem] w-full"
                >
                  <div className="text-brand-orange mb-6">{item.icon}</div>
                  <h5 className="text-xl font-bold text-zinc-950 dark:text-white mb-6">{item.title}</h5>
                  <ul className="space-y-4">
                    {item.points.map(p => (
                      <li key={p} className="text-zinc-500 text-sm flex items-center gap-3">
                        <div className="w-1 h-1 bg-brand-orange rounded-full" />
                        {p}
                      </li>
                    ))}
                  </ul>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, scale: 0.5 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 + 0.2 }}
                  className="my-6 text-brand-orange"
                >
                  <ArrowDown className="w-8 h-8" />
                </motion.div>

                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 + 0.3 }}
                  className="p-10 bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800 rounded-[2.5rem] w-full"
                >
                  <div className="text-emerald-500 mb-6"><CheckCircle2 className="w-8 h-8" /></div>
                  <h5 className="text-xl font-bold text-zinc-950 dark:text-white mb-6">Acumelt Solution</h5>
                  <ul className="space-y-4">
                    {item.solutions.map(s => (
                      <li key={s} className="text-zinc-600 dark:text-zinc-400 text-sm flex items-center gap-3">
                        <div className="w-1 h-1 bg-emerald-500 rounded-full" />
                        {s}
                      </li>
                    ))}
                  </ul>
                </motion.div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};

export default About;
