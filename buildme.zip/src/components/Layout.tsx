import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { Linkedin, Menu, X, ArrowRight, Sun, Moon } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { AcumeltLogo } from './AcumeltLogo';

export const Logo = ({ forceWhite = false }: { forceWhite?: boolean }) => {
  return (
    <div className="flex items-center gap-3 group">
      <AcumeltLogo className="h-10 md:h-12 w-auto" forceWhite={forceWhite} />
    </div>
  );
};

export const ThemeToggle = () => {
  const { theme, toggleTheme } = useTheme();
  
  return (
    <button
      onClick={toggleTheme}
      className="p-2.5 rounded-xl bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400 hover:bg-brand-orange hover:text-white hover:border-brand-orange transition-all duration-300 shadow-lg"
      aria-label="Toggle theme"
    >
      {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
    </button>
  );
};

export const MoltenButton = ({ children, href, primary = true, className = "", isLink = false }: { children: React.ReactNode, href: string, primary?: boolean, className?: string, isLink?: boolean }) => {
  const content = (
    <>
      <span className="relative z-10 flex items-center gap-2">
        {children}
      </span>
      {primary && (
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
      )}
    </>
  );

  const classes = `relative px-8 py-4 font-light tracking-[0.1em] uppercase rounded-full transition-all duration-300 flex items-center justify-center gap-2 overflow-hidden group font-sharp ${
    primary 
      ? 'bg-brand-orange text-white shadow-[0_0_20px_rgba(249,164,49,0.3)] hover:shadow-[0_0_30px_rgba(249,164,49,0.5)]' 
      : 'border border-zinc-300 dark:border-zinc-700 text-zinc-950 dark:text-white hover:border-brand-orange/50 hover:bg-zinc-100 dark:hover:bg-zinc-900'
  } ${className}`;

  if (isLink) {
    return (
      <motion.div whileHover={{ scale: 1.05, y: -2 }} whileTap={{ scale: 0.98 }}>
        <Link to={href} className={classes}>{content}</Link>
      </motion.div>
    );
  }

  return (
    <motion.a
      href={href}
      whileHover={{ scale: 1.05, y: -2 }}
      whileTap={{ scale: 0.98 }}
      className={classes}
    >
      {content}
    </motion.a>
  );
};

export const SectionHeading = ({ subtitle, title, centered = false }: { subtitle: string, title: string, centered?: boolean }) => {
  return (
    <div className={`mb-16 ${centered ? 'text-center' : ''}`}>
      <motion.span
        initial={{ opacity: 0, y: 10 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-xs font-black text-brand-orange tracking-[0.4em] uppercase mb-4 block"
      >
        {subtitle}
      </motion.span>
      <motion.h3
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ delay: 0.1 }}
        className="text-4xl md:text-5xl font-light text-zinc-950 dark:text-white tracking-tight font-sharp uppercase"
      >
        {title}
      </motion.h3>
      <motion.div 
        initial={{ width: 0 }}
        whileInView={{ width: 60 }}
        viewport={{ once: true }}
        transition={{ delay: 0.3, duration: 0.8 }}
        className={`h-1 bg-brand-orange mt-6 ${centered ? 'mx-auto' : ''}`}
      />
    </div>
  );
};

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { name: 'Home', href: '/' },
    { name: 'About Us', href: '/about' },
    { name: 'Infrastructure', href: '/infrastructure' },
    { name: 'Quality', href: '/quality' },
    { name: 'Capabilities', href: '/capabilities' },
    { name: 'Products', href: '/products' },
    { name: 'Contact', href: '/contact' },
  ];

  const isHomePage = location.pathname === '/';
  const shouldForceWhite = isHomePage && !isScrolled;

  return (
    <header 
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${
        isScrolled ? 'bg-white/90 dark:bg-zinc-950/90 backdrop-blur-xl border-b border-zinc-200 dark:border-zinc-800/50 py-3' : 'bg-transparent py-6'
      }`}
    >
      <div className="container mx-auto px-6">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-6">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center"
            >
              <Link to="/" className="group">
                <Logo forceWhite={shouldForceWhite} />
              </Link>
            </motion.div>
          </div>

          <nav className="hidden lg:block">
            <ul className="flex items-center gap-1">
              {navItems.map((item, index) => (
                <motion.li 
                  key={item.name}
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <Link 
                    to={item.href}
                    className={`relative px-4 py-2 text-[13px] font-light tracking-[0.15em] uppercase transition-colors group font-sharp ${
                      shouldForceWhite 
                        ? 'text-white hover:text-white/80' 
                        : (location.pathname === item.href ? 'text-brand-orange' : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-950 dark:hover:text-white')
                    }`}
                  >
                    {item.name}
                    <motion.span 
                      className={`absolute bottom-0 left-4 right-4 h-0.5 bg-brand-orange origin-left ${shouldForceWhite ? 'bg-white' : 'bg-brand-orange'}`}
                      initial={{ scaleX: location.pathname === item.href ? 1 : 0 }}
                      animate={{ scaleX: location.pathname === item.href ? 1 : 0 }}
                      whileHover={{ scaleX: 1 }}
                      transition={{ duration: 0.3 }}
                    />
                  </Link>
                </motion.li>
              ))}
            </ul>
          </nav>

          <div className="flex items-center gap-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
            >
              <ThemeToggle />
            </motion.div>

            <motion.a 
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              href="https://www.linkedin.com/company/acumelt/" 
              target="_blank" 
              rel="noopener noreferrer"
              className={`p-2.5 rounded-xl border transition-all duration-300 ${
                shouldForceWhite 
                  ? 'bg-white/10 border-white/20 text-white hover:bg-white/20' 
                  : 'bg-zinc-100 dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400 hover:bg-brand-orange hover:text-white hover:border-brand-orange'
              }`}
            >
              <Linkedin className="w-5 h-5" />
            </motion.a>
            
            <button 
              className={`lg:hidden p-2 border rounded-xl transition-colors ${
                shouldForceWhite 
                  ? 'bg-white/10 border-white/20 text-white' 
                  : 'text-zinc-950 dark:text-white bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800'
              }`}
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>

        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="lg:hidden absolute top-full left-0 w-full bg-white dark:bg-zinc-950 border-b border-zinc-200 dark:border-zinc-800 shadow-2xl overflow-hidden"
            >
              <ul className="py-8 px-6 space-y-4">
                {navItems.map((item, index) => (
                  <motion.li 
                    key={item.name}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <Link 
                      to={item.href}
                      onClick={() => setIsMobileMenuOpen(false)}
                      className={`text-2xl font-bold transition-colors flex items-center justify-between group ${
                        location.pathname === item.href ? 'text-brand-orange' : 'text-zinc-700 dark:text-zinc-300 hover:text-brand-orange'
                      }`}
                    >
                      {item.name}
                      <ArrowRight className="w-6 h-6 opacity-0 group-hover:opacity-100 -translate-x-4 group-hover:translate-x-0 transition-all" />
                    </Link>
                  </motion.li>
                ))}
              </ul>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </header>
  );
};

const Footer = () => {
  return (
    <footer className="py-20 bg-white dark:bg-zinc-950 border-t border-zinc-200 dark:border-zinc-900">
      <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-16 mb-16 max-w-4xl mx-auto">
          <div className="flex flex-col items-center gap-8">
            <Logo />
            <p className="text-zinc-600 dark:text-zinc-200 text-base max-w-sm text-center font-bold leading-relaxed font-sharp uppercase tracking-[0.1em]">
              Inspiring Casting Excellence
            </p>
          </div>
          
          <div className="text-center">
            <h4 className="text-brand-orange font-black text-xs uppercase tracking-[0.3em] mb-8">Contact Us</h4>
            <div className="text-zinc-700 dark:text-zinc-200 font-bold leading-relaxed space-y-2">
              <a 
                href="mailto:contact@acumelt.com" 
                className="block hover:text-brand-orange transition-colors"
              >
                contact@<span className="text-[#F37021]">acumelt</span>.com
              </a>
              <a 
                href="https://wa.me/918160222587" 
                target="_blank" 
                rel="noopener noreferrer"
                className="block hover:text-brand-orange transition-colors"
              >
                +91 81602 22587
              </a>
            </div>
            <div className="mt-8">
              <h4 className="text-brand-orange font-black text-xs uppercase tracking-[0.3em] mb-4">GSTIN & CIN</h4>
              <p className="text-zinc-700 dark:text-zinc-200 font-bold leading-relaxed">
                GSTIN: 24AAWCA2215L1ZI<br />
                CIN: U2700GJ2021PTC127798
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-center pt-12 border-t border-zinc-200 dark:border-zinc-900 gap-8">
          <div className="flex gap-10">
            <Link to="/privacy" className="text-zinc-500 dark:text-zinc-400 hover:text-brand-orange transition-colors text-xs font-black uppercase tracking-[0.2em]">Privacy</Link>
            <Link to="/terms" className="text-zinc-500 dark:text-zinc-400 hover:text-brand-orange transition-colors text-xs font-black uppercase tracking-[0.2em]">Terms</Link>
          </div>
          <div className="text-zinc-400 dark:text-zinc-600 text-xs font-bold uppercase tracking-[0.3em]">
            © {new Date().getFullYear()} Acumelt Pvt. Ltd.
          </div>
        </div>
      </div>
    </footer>
  );
};

export const Layout = ({ children }: { children: React.ReactNode }) => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [useLocation().pathname]);

  return (
    <div className="min-h-screen bg-white dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 selection:bg-brand-orange selection:text-white font-sans antialiased transition-colors duration-500">
      <Header />
      <main>{children}</main>
      <Footer />
    </div>
  );
};
