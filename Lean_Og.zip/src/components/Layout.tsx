import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { Linkedin, Menu, X, ArrowRight, Sun, Moon } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { AcumeltLogo } from './AcumeltLogo';

export const Logo = ({ forceWhite = false, className = "" }: { forceWhite?: boolean; className?: string }) => {
  return (
    <div className="flex items-center gap-[2vw] group">
      <AcumeltLogo 
        className={`h-[4vw] md:h-[5vw] w-auto ${className}`} 
        forceWhite={forceWhite} 
      />
    </div>
  );
};

export const ThemeToggle = () => {
  const { theme, toggleTheme } = useTheme();

  return (
    <button
      onClick={toggleTheme}
      className="p-[3vw] md:p-[1.5vw] lg:p-[1vw] rounded-[1vw] bg-zinc-100 dark:bg-zinc-900 border-[0.1vw] border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400 hover:bg-brand-orange hover:text-white hover:border-brand-orange transition-all duration-300 shadow-[0_0_2vw_rgba(0,0,0,0.1)]"
      aria-label="Toggle theme"
    >
      {theme === 'dark' ? <Sun className="w-[3.5vw] h-[3.5vw] md:w-[1.8vw] md:h-[1.8vw] lg:w-[1.4vw] lg:h-[1.4vw]" /> : <Moon className="w-[3.5vw] h-[3.5vw] md:w-[1.8vw] md:h-[1.8vw] lg:w-[1.4vw] lg:h-[1.4vw]" />}
    </button>
  );
};

export const MoltenButton = ({ children, href, primary = true, className = "", isLink = false }: { children: React.ReactNode, href: string, primary?: boolean, className?: string, isLink?: boolean }) => {
  const content = (
    <>
      <span className="relative z-10 flex items-center gap-[1vw]">
        {children}
      </span>
      {primary && (
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
      )}
    </>
  );

  const classes = `relative px-[4vw] py-[2vw] font-light tracking-[0.1em] uppercase rounded-full transition-all duration-300 flex items-center justify-center gap-[1vw] overflow-hidden group font-sharp ${
    primary 
      ? 'bg-brand-orange text-white shadow-[0_0_2vw_rgba(249,164,49,0.3)] hover:shadow-[0_0_3vw_rgba(249,164,49,0.5)]' 
      : 'border-[0.1vw] border-zinc-300 dark:border-zinc-700 text-zinc-950 dark:text-white hover:border-brand-orange/50 hover:bg-zinc-100 dark:hover:bg-zinc-900'
  } ${className}`;

  if (isLink) {
    return (
      <motion.div whileHover={{ scale: 1.05, y: "-0.5vh" }} whileTap={{ scale: 0.98 }}>
        <Link to={href} className={classes}>{content}</Link>
      </motion.div>
    );
  }

  return (
    <motion.a
      href={href}
      whileHover={{ scale: 1.05, y: "-0.5vh" }}
      whileTap={{ scale: 0.98 }}
      className={classes}
    >
      {content}
    </motion.a>
  );
};

export const SectionHeading = ({ subtitle, title, centered = false }: { subtitle: string, title: string, centered?: boolean }) => {
  return (
    <div className={`mb-[6vw] ${centered ? 'text-center' : ''}`}>
      <motion.span
        initial={{ opacity: 0, y: "2vh" }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-2xl md:text-[1vw] font-black text-brand-orange tracking-[0.4em] uppercase mb-[2vw] block"
      >
        {subtitle}
      </motion.span>
      <motion.h3
        initial={{ opacity: 0, y: "3vh" }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ delay: 0.1 }}
        className="text-4xl md:text-[3vw] font-light text-zinc-950 dark:text-white tracking-tight font-sharp uppercase"
      >
        {title}
      </motion.h3>
      <motion.div 
        initial={{ width: "0%" }}
        whileInView={{ width: "10%" }}
        viewport={{ once: true }}
        transition={{ delay: 0.3, duration: 0.8 }}
        className={`h-[0.1vw] bg-brand-orange mt-[3vw] ${centered ? 'mx-auto' : ''}`}
      />
    </div>
  );
};

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { name: 'Home', href: '/' },
    { name: 'About Us', href: '/about' },
    { name: 'Infrastructure', href: '/infrastructure' },
    { name: 'Quality', href: '/quality' },
    { name: 'Capabilities', href: '/capabilities' },
    { name: 'Products', href: '/products' },
    { name: 'R&D', href: '/rnd' },
    { name: 'Contact', href: '/contact' },
  ];

  const isHomePage = location.pathname === '/';
  const shouldForceWhite = isHomePage && !isScrolled;

  return (
    <header 
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${
        isScrolled ? 'bg-white/90 dark:bg-zinc-950/90 backdrop-blur-xl border-b-[0.1vw] border-zinc-200 dark:border-zinc-800/50 py-[1.5vw]' : 'bg-transparent py-[3vw]'
      }`}
    >
      <div className="container mx-auto px-[3vw]">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <Link to="/" className="flex items-center flex-1 md:w-auto">
            <Logo 
              forceWhite={shouldForceWhite} 
              className="w-full h-auto md:w-auto md:h-[5vw]" 
            />
          </Link>

          {/* Right group: ThemeToggle + LinkedIn + Mobile Menu Button */}
          <div className="flex items-center gap-0 md:gap-[2vw] flex-shrink-0 ml-[4vw] md:ml-0">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="md:flex-initial"
            >
              <ThemeToggle />
            </motion.div>

            <motion.a 
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              href="https://www.linkedin.com/company/acumelt/" 
              target="_blank" 
              rel="noopener noreferrer"
              className={`md:flex-initial p-[3vw] md:p-[1.5vw] lg:p-[1vw] rounded-[1vw] border-[0.1vw] transition-all duration-300 ${
                shouldForceWhite 
                  ? 'bg-white/10 border-white/20 text-white hover:bg-white/20' 
                  : 'bg-zinc-100 dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400 hover:bg-brand-orange hover:text-white hover:border-brand-orange'
              }`}
            >
              <Linkedin className="w-[3.5vw] h-[3.5vw] md:w-[1.8vw] md:h-[1.8vw] lg:w-[1.4vw] lg:h-[1.4vw]" />
            </motion.a>

            {/* Mobile Menu Button - always visible */}
            <button
              className={`md:flex-initial p-[3vw] md:p-[1.5vw] lg:p-[1vw] border-[0.1vw] rounded-[1vw] transition-colors ${
                shouldForceWhite 
                  ? 'bg-white/10 border-white/20 text-white' 
                  : 'text-zinc-950 dark:text-white bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800'
              }`}
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              aria-label="Menu"
            >
              {isMobileMenuOpen ? <X className="w-[3.5vw] h-[3.5vw] md:w-[1.8vw] md:h-[1.8vw] lg:w-[1.4vw] lg:h-[1.4vw]" /> : <Menu className="w-[3.5vw] h-[3.5vw] md:w-[1.8vw] md:h-[1.8vw] lg:w-[1.4vw] lg:h-[1.4vw]" />}
            </button>
          </div>
        </div>

        <AnimatePresence>
          {isMobileMenuOpen && (
            <>
              {/* Backdrop */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40"
                onClick={() => setIsMobileMenuOpen(false)}
              />
              {/* Menu panel */}
              <motion.div
                initial={{ opacity: 0, y: "-2vh" }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: "-2vh" }}
                className="fixed top-0 left-0 w-full h-screen bg-white dark:bg-zinc-950 shadow-[0_0_4vw_rgba(0,0,0,0.2)] z-50 overflow-y-auto"
              >
                <div className="container mx-auto px-[3vw] py-[4vw]">
                  <div className="flex justify-end mb-[4vw]">
                    <button
                      onClick={() => setIsMobileMenuOpen(false)}
                      className={`p-[3vw] md:p-[1vw] border-[0.1vw] rounded-[1vw] shadow-lg ${
                        shouldForceWhite 
                          ? 'bg-white/10 border-white/20 text-white' 
                          : 'text-zinc-950 dark:text-white bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800'
                      }`}
                    >
                      <X className="w-[3.5vw] h-[3.5vw] md:w-[1.5vw] md:h-[1.5vw]" />
                    </button>
                  </div>
                  <ul className="space-y-[3vw]">
                    {navItems.map((item, index) => (
                      <motion.li 
                        key={item.name}
                        initial={{ opacity: 0, x: "-2vw" }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.05 }}
                      >
                        <Link 
                          to={item.href}
                          onClick={() => setIsMobileMenuOpen(false)}
                          className={`text-4xl md:text-[3vw] font-bold transition-colors flex items-center justify-between group ${
                            location.pathname === item.href ? 'text-brand-orange' : 'text-zinc-700 dark:text-zinc-300 hover:text-brand-orange'
                          }`}
                        >
                          {item.name}
                          <ArrowRight className="w-[2vw] h-[2vw] opacity-0 group-hover:opacity-100 -translate-x-[2vw] group-hover:translate-x-0 transition-all" />
                        </Link>
                      </motion.li>
                    ))}
                  </ul>
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>
    </header>
  );
};

const Footer = () => {
  return (
    <footer className="py-[10vw] bg-white dark:bg-zinc-950 border-t-[0.1vw] border-zinc-200 dark:border-zinc-900">
      <div className="container mx-auto px-[3vw]">
        <div className="grid grid-cols-1 gap-[8vw] mb-[8vw] max-w-[80vw] mx-auto">
          <div className="flex flex-col items-center justify-center w-full gap-[4vw]">
            <Logo forceWhite={false} className="h-[4vw] md:h-[5vw] w-auto mx-auto" />
            <p className="text-zinc-600 dark:text-zinc-200 text-3xl md:text-[1.5vw] max-w-none md:max-w-[40vw] text-center font-bold leading-relaxed font-sharp uppercase tracking-[0.1em]">
              <span className="block md:inline">Inspiring</span>{' '}
              <span className="block md:inline">Casting</span>{' '}
              <span className="block md:inline">Excellence</span>
            </p>
          </div>
          
          <div className="text-center">
            <h4 className="text-brand-orange font-black text-xl md:text-[1vw] uppercase tracking-[0.3em] mb-[4vw]">Contact Us</h4>
            <div className="text-zinc-700 dark:text-zinc-200 text-base md:text-[1.2vw] leading-relaxed space-y-[1vw]">
              <a 
                href="mailto:contact@acumelt.com" 
                className="block hover:text-brand-orange transition-colors"
              >
                contact@<span className="text-brand-orange">acumelt</span>.com
              </a>
              <a 
                href="https://wa.me/918160222587" 
                target="_blank" 
                rel="noopener noreferrer"
                className="block hover:text-brand-orange transition-colors"
              >
                <span className="text-brand-orange">+91</span> 81602 22587
              </a>
            </div>
            <div className="mt-[4vw]">
              <h4 className="text-brand-orange font-black text-xl md:text-[1vw] uppercase tracking-[0.3em] mb-[2vw]">GSTIN & CIN</h4>
              <p className="text-zinc-700 dark:text-zinc-200 text-base md:text-[1.2vw] leading-relaxed">
                <span className="text-brand-orange">GSTIN:</span> 24AAWCA2215L1ZI<br />
                <span className="text-brand-orange">CIN:</span> U2700GJ2021PTC127798
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-center pt-[6vw] border-t-[0.1vw] border-zinc-200 dark:border-zinc-900 gap-[4vw]">
          <div className="flex gap-[5vw]">
            <Link to="/privacy" className="text-zinc-500 dark:text-zinc-400 hover:text-brand-orange transition-colors text-[1vw] font-black uppercase tracking-[0.2em]">Privacy</Link>
            <Link to="/terms" className="text-zinc-500 dark:text-zinc-400 hover:text-brand-orange transition-colors text-[1vw] font-black uppercase tracking-[0.2em]">Terms</Link>
          </div>
          <div className="text-zinc-400 dark:text-zinc-600 text-[1vw] font-bold uppercase tracking-[0.3em]">
            © {new Date().getFullYear()} Acumelt Pvt. Ltd.
          </div>
        </div>
      </div>
    </footer>
  );
};

export const Layout = ({ children }: { children: React.ReactNode }) => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [useLocation().pathname]);

  return (
    <div className="min-h-screen bg-white dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 selection:bg-brand-orange selection:text-white font-sans antialiased transition-colors duration-500 overflow-x-hidden">
      <Header />
      <main>{children}</main>
      <Footer />
    </div>
  );
};
