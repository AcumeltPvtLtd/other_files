import React from 'react';
import { motion } from 'motion/react';
import { Database, Layers } from 'lucide-react';
import { SectionHeading } from '../components/Layout';

interface Column {
  header: string;
  key: string;
  className?: string;
}

const MaterialTable = ({ data, columns }: { data: any[], columns: Column[] }) => (
  <div className="overflow-x-auto">
    <table className="w-full text-center border-collapse min-w-[1000px]">
      <thead>
        <tr className="bg-zinc-100 dark:bg-zinc-950/50">
          {columns.map((col, i) => (
            <th
              key={i}
              className={`p-4 text-brand-orange font-black text-[10px] uppercase tracking-widest text-center ${
                i === 0
                  ? 'sticky left-0 z-10 bg-zinc-100 dark:bg-zinc-950/50 md:static md:left-auto'
                  : ''
              }`}
            >
              {col.header}
            </th>
          ))}
        </tr>
      </thead>
      <tbody className="divide-y divide-zinc-200 dark:divide-zinc-800">
        {data.map((row, idx) => (
          <tr
            key={idx}
            className="hover:bg-zinc-50 dark:hover:bg-zinc-800/30 transition-colors"
          >
            {columns.map((col, i) => (
              <td
                key={i}
                className={`p-4 text-sm text-center ${
                  col.className || 'text-zinc-600 dark:text-zinc-400'
                } ${
                  i === 0
                    ? 'sticky left-0 z-10 bg-zinc-50 dark:bg-zinc-900 hover:bg-zinc-50 dark:hover:bg-zinc-800/30 md:static md:left-auto'
                    : ''
                }`}
              >
                {row[col.key] || '-'}
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  </div>
);

const Capabilities = () => {
  const ductileGrades = [
    { simple: '350-22', standard: 'ISO 1083', spec: 'EN-GJS-350-22', yield: '220', tensile: '350', elongation: '22', hardness: '<=150' },
    { simple: '400-18', standard: 'ISO 1083', spec: 'EN-GJS-400-18', yield: '250', tensile: '400', elongation: '18', hardness: '130-180' },
    { simple: '450-10', standard: 'ISO 1083', spec: 'EN-GJS-450-10', yield: '310', tensile: '450', elongation: '10', hardness: '160-210' },
    { simple: '500-7', standard: 'ISO 1083', spec: 'EN-GJS-500-7', yield: '320', tensile: '500', elongation: '7', hardness: '170-230' },
    { simple: '550-5', standard: 'ISO 1083', spec: 'EN-GJS-550-5', yield: '350', tensile: '550', elongation: '5', hardness: '180-250' },
    { simple: '600-3', standard: 'ISO 1083', spec: 'EN-GJS-600-3', yield: '370', tensile: '600', elongation: '3', hardness: '190-270' },
    { simple: '700-2', standard: 'ISO 1083', spec: 'EN-GJS-700-2', yield: '420', tensile: '700', elongation: '2', hardness: '225-305' },
  ];

  const ssDuctileGrades = [
    { simple: '450-18', standard: 'ISO 1083', spec: 'EN-GJS-450-18', si: '3.2-3.8', yield: '350', tensile: '450', elongation: '18', hardness: '160-210' },
    { simple: '500-14', standard: 'ISO 1083', spec: 'EN-GJS-500-14', si: '3.4-4.0', yield: '400', tensile: '500', elongation: '14', hardness: '170-230' },
    { simple: '600-10', standard: 'ISO 1083', spec: 'EN-GJS-600-10', si: '3.6-4.3', yield: '450', tensile: '600', elongation: '10', hardness: '190-260' },
  ];

  const adiGrades = [
    { simple: 'ADI Grade 1', standard: 'ASTM A897', spec: '750-500-11', yield: '500', tensile: '750', elongation: '11', hardness: '241-302', charpy: '110' },
    { simple: 'ADI Grade 2', standard: 'ASTM A897', spec: '900-650-09', yield: '650', tensile: '900', elongation: '9', hardness: '269-341', charpy: '100' },
    { simple: 'ADI Grade 3', standard: 'ASTM A897', spec: '1050-750-07', yield: '750', tensile: '1050', elongation: '7', hardness: '302-375', charpy: '80' },
    { simple: 'ADI Grade 4', standard: 'ASTM A897', spec: '1200-850-04', yield: '850', tensile: '1200', elongation: '4', hardness: '341-444', charpy: '60' },
    { simple: 'ADI Grade 5', standard: 'ASTM A897', spec: '1400-1100-02', yield: '1100', tensile: '1400', elongation: '2', hardness: '388-477', charpy: '35' },
    { simple: 'ADI Grade 6', standard: 'ASTM A897', spec: '1600-1300-01', yield: '1300', tensile: '1600', elongation: '1', hardness: '402-512', charpy: '20' },
  ];

  const simoGrades = [
    { simple: 'SiMo 4-0.5', num: '5.3103', standard: 'DIN EN 16124', spec: 'EN-GJS-SiMo4-0.5', si: '3.8-4.2', mo: '0.4-0.6', yield: '240', tensile: '400', elongation: '12', hardness: '160-220' },
    { simple: 'SiMo 4-1', num: '5.3104', standard: 'DIN EN 16124', spec: 'EN-GJS-SiMo4-1', si: '3.8-4.3', mo: '0.8-1.2', yield: '260', tensile: '420', elongation: '10', hardness: '170-230' },
    { simple: 'SiMo 5-1', num: '5.3105', standard: 'DIN EN 16124', spec: 'EN-GJS-SiMo5-1', si: '4.5-5.0', mo: '0.8-1.2', yield: '280', tensile: '450', elongation: '8', hardness: '180-240' },
    { simple: 'SiMo 5-2', num: '5.3106', standard: 'DIN EN 16124', spec: 'EN-GJS-SiMo5-2', si: '4.5-5.2', mo: '1.8-2.2', yield: '300', tensile: '480', elongation: '6', hardness: '190-260' },
    { simple: 'SiMo 25-5', num: '5.3210', standard: 'DIN EN 16124', spec: 'EN-GJS-SiMo25-5', si: '2.3-2.7', mo: '0.4-0.6', yield: '380*', tensile: '450*', elongation: '10*', hardness: '170-230*' },
    { simple: 'SiMo 30-7', num: '5.3220', standard: 'DIN EN 16124', spec: 'EN-GJS-SiMo30-7', si: '2.8-3.2', mo: '0.6-0.8', yield: '420*', tensile: '500*', elongation: '6*', hardness: '180-240*' },
    { simple: 'SiMo 35-5', num: '5.3230', standard: 'DIN EN 16124', spec: 'EN-GJS-SiMo35-5', si: '3.3-3.7', mo: '0.4-0.6', yield: '450*', tensile: '550*', elongation: '4*', hardness: '190-250*' },
    { simple: 'SiMo 40-6', num: '5.3240', standard: 'DIN EN 16124', spec: 'EN-GJS-SiMo40-6', si: '3.8-4.2', mo: '0.5-0.7', yield: '380', tensile: '480', elongation: '8', hardness: '190-240' },
    { simple: 'SiMo 40-10', num: '5.3250', standard: 'DIN EN 16124', spec: 'EN-GJS-SiMo40-10', si: '3.8-4.2', mo: '0.8-1.1', yield: '400', tensile: '510', elongation: '6', hardness: '190-240' },
    { simple: 'SiMo 45-6', num: '5.3260', standard: 'DIN EN 16124', spec: 'EN-GJS-SiMo45-6', si: '4.3-4.7', mo: '0.5-0.7', yield: '420', tensile: '520', elongation: '7', hardness: '200-250' },
    { simple: 'SiMo 45-10', num: '5.3270', standard: 'DIN EN 16124', spec: 'EN-GJS-SiMo45-10', si: '4.3-4.7', mo: '0.8-1.1', yield: '460', tensile: '550', elongation: '5', hardness: '200-250' },
    { simple: 'SiMo 50-6', num: '5.3300', standard: 'DIN EN 16124', spec: 'EN-GJS-SiMo50-6', si: '4.8-5.2', mo: '0.5-0.7', yield: '480', tensile: '580', elongation: '4', hardness: '210-260' },
    { simple: 'SiMo 50-10', num: '5.3310', standard: 'DIN EN 16124', spec: 'EN-GJS-SiMo50-10', si: '4.8-5.2', mo: '0.8-1.1', yield: '500', tensile: '600', elongation: '3', hardness: '210-260' },
  ];

  const baseCols = [
    { header: 'Grade', key: 'simple', className: 'text-zinc-950 dark:text-white font-bold' },
    { header: 'Standard', key: 'standard' },
    { header: 'Specification', key: 'spec' },
    { header: 'Yield (MPa)', key: 'yield' },
    { header: 'Tensile (MPa)', key: 'tensile' },
    { header: 'Elongation (%)', key: 'elongation' },
    { header: 'Hardness (HB)', key: 'hardness' },
  ];

  return (
    <div className="pt-32 pb-20 bg-white dark:bg-zinc-950 transition-colors duration-300">
      <div className="container mx-auto px-6">
        <SectionHeading subtitle="" title=" Scope Of Material Grade " centered />
        
        <div className="space-y-16">
            {/* 3D Visualization */}
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-[4rem] overflow-hidden"
            >
              <div className="p-12 border-b border-zinc-200 dark:border-zinc-800 flex items-center gap-6">
                <div className="p-4 bg-brand-orange/10 rounded-2xl text-brand-orange">
                  <Layers className="w-8 h-8" />
                </div>
                <div>
                  <h4 className="text-xl md:text-3xl font-bold text-zinc-950 dark:text-white">
                    3D Mold Visualization
                  </h4>
                  <p className="text-zinc-500 text-xs md:text-base font-black uppercase tracking-widest mt-1">
                    Interactive Casting Mold
                  </p>
                  <p className="text-zinc-500 text-xs md:text-base font-black uppercase tracking-widest mt-1">
                    Outer: 508×660×500 mm | Safety: 408×560×350 mm
                  </p>
                  <p className="text-zinc-500 text-xs md:text-base font-black uppercase tracking-widest mt-2">
                    Max Pouring Weight: 50 KG
                  </p>
                </div>
              </div>
              <div className="relative w-full aspect-video min-h-[400px] md:min-h-[600px] bg-zinc-100 dark:bg-zinc-950">
                <iframe 
                  src="https://acumeltpvtltd.github.io/3d/moldbox.html" 
                  className="absolute inset-0 w-full h-full border-0"
                  title="3D Mold Visualization"
                  allowFullScreen
                />
              </div>
            </motion.div>

            {/* Ductile Iron Grades */}
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-[4rem] overflow-hidden"
            >
              <div className="p-12 border-b border-zinc-200 dark:border-zinc-800 flex items-center gap-6">
                <div className="p-4 bg-brand-orange/10 rounded-2xl text-brand-orange">
                  <Database className="w-8 h-8" />
                </div>
                <div>
                  <h4 className="text-xl md:text-3xl font-bold text-zinc-950 dark:text-white">Ductile Iron Grades</h4>
                  <p className="text-zinc-500 dark:text-zinc-500 text-xs font-black uppercase tracking-widest mt-1">ISO 1083 | DIN EN 1563 | ASTM A536</p>
                </div>
              </div>
              <MaterialTable data={ductileGrades} columns={baseCols} />
            </motion.div>

            {/* Solution Strengthened Ductile Iron Grades */}
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-[4rem] overflow-hidden"
            >
              <div className="p-12 border-b border-zinc-200 dark:border-zinc-800 flex items-center gap-6">
                <div className="p-4 bg-brand-orange/10 rounded-2xl text-brand-orange">
                  <Database className="w-8 h-8" />
                </div>
                <div>
                  <h4 className="text-xl md:text-3xl font-bold text-zinc-950 dark:text-white">Solution Strengthened Ductile Iron</h4>
                  <p className="text-zinc-500 dark:text-zinc-500 text-xs font-black uppercase tracking-widest mt-1">ISO 1083 | DIN EN 1563</p>
                </div>
              </div>
              <MaterialTable 
                data={ssDuctileGrades} 
                columns={[
                  ...baseCols.slice(0, 3),
                  { header: 'Si %', key: 'si', className: 'text-brand-orange/70' },
                  ...baseCols.slice(3)
                ]} 
              />
            </motion.div>

            {/* ADI Grades */}
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-[4rem] overflow-hidden"
            >
              <div className="p-12 border-b border-zinc-200 dark:border-zinc-800 flex items-center gap-6">
                <div className="p-4 bg-brand-orange/10 rounded-2xl text-brand-orange">
                  <Database className="w-8 h-8" />
                </div>
                <div>
                  <h4 className="text-xl md:text-3xl font-bold text-zinc-950 dark:text-white">ADI Grades</h4>
                  <p className="text-zinc-500 dark:text-zinc-500 text-xs font-black uppercase tracking-widest mt-1">ISO 17804 | DIN EN 1564 | ASTM A897</p>
                </div>
              </div>
              <MaterialTable 
                data={adiGrades} 
                columns={[
                  ...baseCols,
                  { header: 'Charpy (J)', key: 'charpy' }
                ]} 
              />
            </motion.div>

            {/* SiMo Ductile Iron */}
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-[4rem] overflow-hidden"
            >
              <div className="p-12 border-b border-zinc-200 dark:border-zinc-800 flex items-center gap-6">
                <div className="p-4 bg-brand-orange/10 rounded-2xl text-brand-orange">
                  <Layers className="w-8 h-8" />
                </div>
                <div>
                  <h4 className="text-xl md:text-3xl font-bold text-zinc-950 dark:text-white">SiMo Ductile Iron</h4>
                  <p className="text-zinc-500 dark:text-zinc-500 text-xs font-black uppercase tracking-widest mt-1">DIN EN 16124 | ASTM A1095</p>
                </div>
              </div>
              <MaterialTable 
                data={simoGrades} 
                columns={[
                  baseCols[0],
                  { header: 'Number', key: 'num' },
                  ...baseCols.slice(1, 3),
                  { header: 'Si %', key: 'si', className: 'text-brand-orange/70' },
                  { header: 'Mo %', key: 'mo', className: 'text-brand-orange/70' },
                  ...baseCols.slice(3)
                ]} 
              />
              <div className="p-8 bg-zinc-100 dark:bg-zinc-950/30 border-t border-zinc-200 dark:border-zinc-800">
                <p className="text-zinc-500 dark:text-zinc-500 text-[10px] uppercase tracking-widest leading-relaxed">
                  * Values for SiMo 25-5, 30-7, and 35-5 are provided as guidance only according to <span className="text-brand-orange/50">DIN EN 16124 Annex A</span>. These are reference values and not mandatory requirements.
                </p>
              </div>
            </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Capabilities;
