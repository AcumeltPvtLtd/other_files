import React from 'react';
import { motion, useScroll, useTransform } from 'motion/react';
import { ArrowRight, Zap, Factory, Cpu, ShieldCheck, Settings, Thermometer, Paintbrush, Sparkles } from 'lucide-react';
import { MoltenButton, SectionHeading } from '../components/Layout';

export const Hero = () => {
  const { scrollY } = useScroll();
  const y1 = useTransform(scrollY, [0, 500], [0, 200]);
  const opacity = useTransform(scrollY, [0, 300], [1, 0]);

  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden bg-white dark:bg-zinc-950">
      <motion.div style={{ y: y1 }} className="absolute inset-0 z-0">
        <img 
          src="https://raw.githubusercontent.com/AcumeltPvtLtd/website_images_and_media/main/pouring/70370.jpeg" 
          alt="Foundry Background" 
          className="w-full h-full object-cover opacity-100 dark:opacity-70 scale-110"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-transparent dark:bg-zinc-950/30" />
        
        <div className="absolute inset-0 bg-gradient-to-t from-transparent dark:from-zinc-900/60 to-transparent" />
      </motion.div>
      
      <div className="container mx-auto px-6 z-10 text-center pt-24 md:pt-32">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
          style={{ opacity }}
        >
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-brand-orange/10 border border-brand-orange/20 text-brand-orange text-xs font-black tracking-[0.3em] uppercase mb-8"
          >
            <Zap className="w-3 h-3 fill-brand-orange" />
            
          </motion.div>
          
          <h1 className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl font-light text-white mb-8 tracking-[0.05em] leading-tight drop-shadow-2xl font-sharp uppercase transition-colors duration-500 break-words whitespace-normal max-w-full">
            Inspiring <br />
            <span className="text-brand-orange">Casting</span> Excellence
          </h1>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <MoltenButton href="/contact" isLink>
              SEND AN INQUIRY <ArrowRight className="w-5 h-5" />
            </MoltenButton>
          </div>
        </motion.div>
      </div>

    </section>
  );
};

const Home = () => {
  return (
    <>
      <Hero />
      <section className="py-32 bg-white dark:bg-zinc-950 border-y border-zinc-100 dark:border-zinc-900 transition-colors duration-500">
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-20 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <SectionHeading subtitle="" title=" Expertise in Ductile Iron Casting" />
              <div className="space-y-6 text-zinc-600 dark:text-zinc-400 leading-relaxed text-lg font-light transition-colors duration-500">
                <p className="text-justify">
                  Acumelt is a Rajkot-based ductile iron component manufacturer offering complete in-house solutions from casting and heat treatment to machining and surface finishing.
                </p>
                <p className="text-justify">
                  Committed to delivering the highest quality components at competitive prices, Acumelt pursues sustainable and healthy growth through continuous process improvement, advanced manufacturing practices, and long-term partnerships with customers and stakeholders.
                </p>
                <p className="text-justify">
                  The company operates with state-of-the-art infrastructure and a team of experienced, capable personnel, ensuring consistent quality, reliability, and efficiency across all manufacturing processes.
                </p>
              </div>
              <div className="mt-12">
                <MoltenButton href="/about" isLink primary={false}>
                  LEARN MORE ABOUT US
                </MoltenButton>
              </div>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="relative"
            >
              <div className="aspect-square rounded-[3rem] overflow-hidden border border-zinc-200 dark:border-zinc-800 shadow-2xl group">
                <img 
                  src="https://raw.githubusercontent.com/AcumeltPvtLtd/website_images_and_media/main/pouring/70358.jpeg" 
                  alt="Pouring Process" 
                  className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110 opacity-100 dark:opacity-90"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-transparent" />
                <div className="absolute inset-0 bg-brand-orange/10 opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="py-32 bg-zinc-50 dark:bg-zinc-950 transition-colors duration-500">
        <div className="container mx-auto px-6">
          <SectionHeading subtitle="Capabilities" title="Advanced Infrastructure" centered />
          <div className="grid lg:grid-cols-3 gap-12">
            {[
              {
                title: 'Melting',
                icon: <Factory className="w-10 h-10" />,
                desc: 'Inductotherm Duraline Tritrack Furnace with Medium frequency induction melting. 2.5 Metric Tons Per Hour Melting Capacity.',
                image: 'https://raw.githubusercontent.com/AcumeltPvtLtd/website_images_and_media/main/melting/1.jpeg'
              },
              {
                title: 'Molding',
                icon: <Cpu className="w-10 h-10" />,
                desc: 'Sinto FBO III A(N) High Pressure Flaskless Molding Line. 120 Molds Per Hour with 50 Kilograms maximum pouring weight.',
                image: 'https://raw.githubusercontent.com/AcumeltPvtLtd/website_images_and_media/main/molding_line/molding-image-1-1024x906.webp'
              },
              {
                title: 'Sand Plant',
                icon: <ShieldCheck className="w-10 h-10" />,
                desc: 'Savelli automated sand plant with multicooler and online testing. 24 MT/hr capacity with SCADA control.',
                image: 'https://raw.githubusercontent.com/AcumeltPvtLtd/website_images_and_media/main/sand_plant/Sand-plant-image-1-768x679.webp'
              }
            ].map((item, idx) => (
              <motion.div 
                key={item.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="group relative bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800/50 rounded-[3rem] overflow-hidden hover:border-brand-orange/30 transition-all duration-500 p-12 shadow-xl dark:shadow-none"
              >
                <div className="mb-10 p-5 bg-zinc-100 dark:bg-zinc-800/50 rounded-2xl w-fit text-brand-orange group-hover:bg-brand-orange group-hover:text-white transition-all duration-500 shadow-xl">
                  {item.icon}
                </div>
                <h4 className="text-2xl font-light text-zinc-950 dark:text-white mb-4 group-hover:text-brand-orange transition-colors font-sharp uppercase tracking-normal">{item.title}</h4>
                <p className="text-zinc-600 dark:text-zinc-400 mb-10 leading-relaxed text-lg font-light text-justify transition-colors duration-500">
                  {item.desc}
                </p>
                <div className="aspect-[16/10] rounded-[2rem] overflow-hidden border border-zinc-200 dark:border-zinc-800 shadow-2xl relative">
                  <img 
                    src={item.image} 
                    alt={item.title} 
                    className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110 opacity-100 dark:opacity-90" 
                    referrerPolicy="no-referrer" 
                  />
                  <div className="absolute inset-0 bg-transparent" />
                </div>
              </motion.div>
            ))}
          </div>
          <div className="mt-16 text-center">
            <MoltenButton href="/infrastructure" isLink>
              VIEW ALL INFRASTRUCTURE <ArrowRight className="w-5 h-5" />
            </MoltenButton>
          </div>
        </div>
      </section>

      {/* New Section: Precision Finishing & Quality */}
      <section className="py-32 bg-white dark:bg-zinc-950 border-y border-zinc-100 dark:border-zinc-900 transition-colors duration-500">
        <div className="container mx-auto px-6">
          <SectionHeading subtitle="From Casting to Completion" title="Precision Finishing & Quality" centered />
          <div className="grid lg:grid-cols-4 gap-8">
            {[
              {
                title: 'CNC Machining',
                icon: <Settings className="w-10 h-10" />,
                desc: 'High‑precision CNC turning, milling, and drilling centers for tight tolerances and superior surface finishes.',
                media: 'https://raw.githubusercontent.com/AcumeltPvtLtd/website_images_and_media/main/machine_shop/VMC/Doosan_DNM_500_II_.mp4',
                type: 'video'
              },
              {
                title: 'Heat Treatment',
                icon: <Thermometer className="w-10 h-10" />,
                desc: 'Controlled annealing, normalizing, and quenching to enhance mechanical properties and microstructure.',
                media: 'https://raw.githubusercontent.com/AcumeltPvtLtd/website_images_and_media/main/heat_treatment/heat_treatment_plant.jpg',
                type: 'image' // changed from video to image because only image exists
              },
              {
                title: 'Surface Finishing',
                icon: <Paintbrush className="w-10 h-10" />,
                desc: 'Advanced painting and coating systems for corrosion resistance and aesthetic durability.',
                media: 'https://raw.githubusercontent.com/AcumeltPvtLtd/website_images_and_media/main/paint_shop/0b83ca38-e603-45c2-b379-a65cfd53dbd2.jpg',
                type: 'image'
              },
              {
                title: 'Shot Blasting',
                icon: <Sparkles className="w-10 h-10" />,
                desc: 'Efficient shot blasting for scale removal and surface preparation before finishing.',
                media: 'https://raw.githubusercontent.com/AcumeltPvtLtd/website_images_and_media/main/shot_blasting/70331.jpeg',
                type: 'image'
              }
            ].map((item, idx) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="group relative bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800/50 rounded-[2rem] overflow-hidden hover:border-brand-orange/30 transition-all duration-500 p-8 shadow-lg dark:shadow-none"
              >
                <div className="mb-6 p-4 bg-white dark:bg-zinc-800 rounded-xl w-fit text-brand-orange group-hover:bg-brand-orange group-hover:text-white transition-all duration-500 shadow-md">
                  {item.icon}
                </div>
                <h4 className="text-xl font-semibold text-zinc-950 dark:text-white mb-3 group-hover:text-brand-orange transition-colors font-sharp uppercase tracking-tight">
                  {item.title}
                </h4>
                <p className="text-zinc-600 dark:text-zinc-400 mb-6 leading-relaxed text-base font-light text-justify transition-colors duration-500">
                  {item.desc}
                </p>
                <div className="aspect-video rounded-xl overflow-hidden border border-zinc-200 dark:border-zinc-800 shadow-lg relative">
                  {item.type === 'video' ? (
                    <video
                      src={item.media}
                      autoPlay
                      loop
                      muted
                      playsInline
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                  ) : (
                    <img
                      src={item.media}
                      alt={item.title}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 opacity-100 dark:opacity-90"
                      referrerPolicy="no-referrer"
                    />
                  )}
                </div>
              </motion.div>
            ))}
          </div>
          <div className="mt-16 text-center">
            <MoltenButton href="/processes" isLink>
              DISCOVER OUR PROCESSES <ArrowRight className="w-5 h-5" />
            </MoltenButton>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;
