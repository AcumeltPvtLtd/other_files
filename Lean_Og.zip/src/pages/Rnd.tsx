import React from 'react';
import { motion } from 'motion/react';
import {
  Box, Code, Share2, ArrowRight, Layers,
  FlaskConical, Microscope, Activity, Cpu,
  BookOpen, Database, FileText, GraduationCap
} from 'lucide-react';
import { SectionHeading, MoltenButton } from '../components/Layout';

const Rnd = () => {
  const tools = [
    {
      name: 'FreeCAD',
      icon: <Box className="w-12 h-12" />,
      description: 'Parametric 3D modeling for complex cast geometries. We use FreeCAD to create precise solid models, generate 2D drawings, and perform finite element analysis (FEM) integration for early design validation.',
      image: 'https://raw.githubusercontent.com/AcumeltPvtLtd/website_images_and_media/main/Rnd/freecad.png',
    },
    {
      name: 'OpenSCAD',
      icon: <Code className="w-12 h-12" />,
      description: 'Script‑based solid modeling for fully parametric and reproducible designs. Our R&D team leverages OpenSCAD to automate geometry generation, enabling rapid iteration and version control of casting models.',
      image: 'https://raw.githubusercontent.com/AcumeltPvtLtd/website_images_and_media/main/Rnd/openscad.png',
    },
    {
      name: 'Polygonsoft ',
      icon: <Share2 className="w-12 h-12" />,
      description: 'Advanced computational fluid & dynamics (CFD) and solidification simulation. We use Polygonsoft to optimize gating systems, predict shrinkage porosity, and ensure high‑quality castings with minimal trial runs.',
      image: 'https://raw.githubusercontent.com/AcumeltPvtLtd/website_images_and_media/main/Rnd/polygonsoft.png',
    },
    {
      name: 'SolidWorks',
      icon: <Layers className="w-12 h-12" />,
      description: 'Industry‑standard CAD for detailed part and assembly design. We integrate SolidWorks with our simulation workflow to produce manufacturable ductile iron components with precision.',
      image: 'https://raw.githubusercontent.com/AcumeltPvtLtd/website_images_and_media/main/Rnd/solid_works.png',
    },
  ];

  const capabilities = [
    {
      name: 'Material Modeling',
      icon: <FlaskConical className="w-12 h-12" />,
      description: 'Predictive modeling of ductile iron microstructure, mechanical properties, and thermal behavior to optimize alloy design and heat treatment.',
      image: 'https://raw.githubusercontent.com/AcumeltPvtLtd/website_images_and_media/main/Rnd/material_modeling.png',
    },
    {
      name: 'Process Simulation',
      icon: <Microscope className="w-12 h-12" />,
      description: 'End‑to‑end casting simulation covering mold filling, solidification, and residual stress analysis to eliminate defects before production.',
      image: 'https://raw.githubusercontent.com/AcumeltPvtLtd/website_images_and_media/main/Rnd/process_simulation.png',
    },
    {
      name: 'Rapid Prototyping',
      icon: <Cpu className="w-12 h-12" />,
      description: 'Additive manufacturing and CNC prototyping for quick design validation, functional testing, and customer approval cycles.',
      image: 'https://raw.githubusercontent.com/AcumeltPvtLtd/website_images_and_media/main/Rnd/rapid_prototyping.png',
    },
  ];

  const resources = tools; // Use the same four objects from the Tools Grid

  return (
    <div className="pt-32 pb-20 bg-white dark:bg-zinc-950 transition-colors duration-300">
      <div className="container mx-auto px-6">
        <SectionHeading
          subtitle="Innovation Through Digital Engineering"
          title="Research & Development"
          centered
        />

        {/* Introduction */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto text-center mb-20"
        >
          <p className="text-zinc-600 dark:text-zinc-400 text-xl font-light leading-relaxed">
            At Acumelt, our R&D team harnesses the power of open‑source and commercial digital tools to accelerate innovation,
            reduce time‑to‑market, and deliver superior ductile iron components. We combine parametric design, script‑based modeling,
            and advanced simulation to achieve predictable and repeatable results.
          </p>
        </motion.div>

        {/* Capabilities Section */}
        <section className="mb-20">
          <SectionHeading
            subtitle="Core Expertise"
            title="Capabilities"
            centered
          />
          <div className="grid lg:grid-cols-3 gap-12 mt-12">
            {capabilities.map((cap, idx) => (
              <motion.div
                key={cap.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="group bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-[2.5rem] p-8 hover:border-brand-orange/30 transition-all duration-500"
              >
                <div className="text-brand-orange mb-6">{cap.icon}</div>
                <h3 className="text-2xl font-bold text-zinc-950 dark:text-white mb-4">{cap.name}</h3>
                <p className="text-zinc-600 dark:text-zinc-400 text-sm leading-relaxed mb-6">{cap.description}</p>
                <div className="relative aspect-video rounded-xl overflow-hidden">
                  <img
                    src={cap.image}
                    alt={cap.name}
                    className="w-full h-full object-cover opacity-90 group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-zinc-50 dark:from-zinc-900 to-transparent opacity-40" />
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Resources Section */}
        <section className="mb-20">
          <SectionHeading
            subtitle="Knowledge Hub"
            title="Resources"
            centered
          />
          <div className="grid lg:grid-cols-4 gap-12 mt-12">
            {resources.map((resource, idx) => (
              <motion.div
                key={resource.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="group bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-[2.5rem] p-8 hover:border-brand-orange/30 transition-all duration-500"
              >
                <div className="text-brand-orange mb-6">{resource.icon}</div>
                <h3 className="text-2xl font-bold text-zinc-950 dark:text-white mb-4">{resource.name}</h3>
                <p className="text-zinc-600 dark:text-zinc-400 text-sm leading-relaxed mb-6">{resource.description}</p>
                <div className="relative aspect-video rounded-xl overflow-hidden">
                  <img
                    src={resource.image}
                    alt={resource.name}
                    className="w-full h-full object-cover opacity-90 group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-zinc-50 dark:from-zinc-900 to-transparent opacity-40" />
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Call to Action */}
        <div className="text-center">
          <MoltenButton href="/contact" primary isLink>
            Partner with Our R&D Team <ArrowRight className="w-5 h-5" />
          </MoltenButton>
        </div>
      </div>
    </div>
  );
};

export default Rnd;
