import React, { useRef, useState, useEffect, useCallback } from 'react';
import { motion, useMotionValue, useAnimationFrame, AnimatePresence } from 'framer-motion';
import {
  Globe, Briefcase, Train, Truck, Factory, Cog, X, ChevronLeft, ChevronRight, Maximize2
} from 'lucide-react';
import { SectionHeading } from '../components/Layout';

// ----------------------------------------------------------------------
// GitHub raw content base URL
// ----------------------------------------------------------------------
const GITHUB_RAW_BASE = 'https://raw.githubusercontent.com/AcumeltPvtLtd/website_images_and_media/main';

// ----------------------------------------------------------------------
// Media list for product images (1.jpeg through 35.jpeg)
// ----------------------------------------------------------------------
const productImageUrls = Array.from({ length: 35 }, (_, i) => ({
  src: `${GITHUB_RAW_BASE}/product/${i + 1}.jpeg`,
  id: i + 1
}));

// ----------------------------------------------------------------------
// Lightbox Component
// ----------------------------------------------------------------------
const MediaLightbox = ({ isOpen, mediaList, currentMedia, currentIndex, onClose, onNext, onPrev }: any) => {
  if (!isOpen) return null;
  const isVideo = currentMedia && currentMedia.endsWith('.mp4');

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black/95 backdrop-blur-lg"
      onClick={onClose}
    >
      <div className="relative w-full h-full flex items-center justify-center pointer-events-none">
        <button
          onClick={(e) => { e.stopPropagation(); onPrev(); }}
          className="absolute left-4 md:left-8 z-20 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all backdrop-blur-md pointer-events-auto border border-white/10"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>

        <div className="relative max-w-[90vw] max-h-[90vh] pointer-events-auto">
          {isVideo ? (
            <video
              src={currentMedia}
              autoPlay
              muted
              loop
              playsInline
              controls
              className="max-w-full max-h-[90vh] object-contain rounded-lg shadow-2xl"
            />
          ) : (
            <img
              src={currentMedia}
              alt="Product"
              className="max-w-full max-h-[90vh] object-contain rounded-lg shadow-2xl"
            />
          )}
        </div>

        <button
          onClick={(e) => { e.stopPropagation(); onNext(); }}
          className="absolute right-4 md:right-8 z-20 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all backdrop-blur-md pointer-events-auto border border-white/10"
        >
          <ChevronRight className="w-6 h-6" />
        </button>

        <button
          onClick={(e) => { e.stopPropagation(); onClose(); }}
          className="absolute top-4 right-4 md:top-8 md:right-8 z-20 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all backdrop-blur-md pointer-events-auto border border-white/10"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 bg-black/60 backdrop-blur-md px-4 py-2 rounded-full text-white text-sm font-mono pointer-events-auto">
          {currentIndex + 1} / {mediaList.length}
        </div>
      </div>
    </motion.div>
  );
};

// ----------------------------------------------------------------------
// Infinite Slider Component
// ----------------------------------------------------------------------
const InfiniteSlider = ({ items, renderCard, baseSpeed = 1, isPaused, onTogglePause, onItemClick }: any) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const x = useMotionValue(0);
  const [isDragging, setIsDragging] = useState(false);
  const [contentWidth, setContentWidth] = useState(0);
  const justDragged = useRef(false);

  const duplicatedItems = [...items, ...items, ...items];

  useEffect(() => {
    if (contentRef.current) setContentWidth(contentRef.current.scrollWidth / 3);
  }, [items]);

  useAnimationFrame((_, delta) => {
    if (isPaused || isDragging || contentWidth === 0) return;
    const deltaMove = baseSpeed * (delta / 10);
    let newX = x.get() - deltaMove;
    newX = ((newX % contentWidth) + contentWidth) % contentWidth - contentWidth;
    x.set(newX);
  });

  const handleDragStart = () => { setIsDragging(true); justDragged.current = true; };
  const handleDragEnd = () => { setIsDragging(false); setTimeout(() => { justDragged.current = false; }, 100); };

  const handleContainerClick = () => {
    if (!justDragged.current) onTogglePause();
  };

  return (
    <div
      ref={containerRef}
      className="relative overflow-hidden py-10 cursor-grab active:cursor-grabbing"
      onClick={handleContainerClick}
    >
      <motion.div
        ref={contentRef}
        className={`flex gap-8 ${isDragging ? 'pointer-events-none' : ''}`}
        style={{ x }}
        drag="x"
        onDragStart={handleDragStart}
        onDragEnd={handleDragEnd}
        dragElastic={0.05}
        dragMomentum={false}
      >
        {duplicatedItems.map((item, idx) => (
          <div key={idx} className="flex-shrink-0 w-[85vw] md:w-[500px] select-none">
            {renderCard(item, (it: any) => onItemClick(it, items))}
          </div>
        ))}
      </motion.div>
    </div>
  );
};

// ----------------------------------------------------------------------
// Main Component
// ----------------------------------------------------------------------
const Products = () => {
  // Customer segments data (icon + title only)
  const customerSegments = [
    { title: 'Automotive', icon: <Globe className="w-8 h-8" /> },
    { title: 'Agriculture', icon: <Briefcase className="w-8 h-8" /> },
    { title: 'Infrastructure', icon: <Globe className="w-8 h-8" /> },
    { title: 'Railway', icon: <Train className="w-8 h-8" /> }
  ];

  // Lightbox state
  const [lightboxState, setLightboxState] = useState<{
    isOpen: boolean;
    mediaList: string[];
    currentMedia: string;
    currentIndex: number;
  }>({
    isOpen: false,
    mediaList: [],
    currentMedia: '',
    currentIndex: 0,
  });

  const openLightbox = useCallback((clickedMedia: string, mediaList: string[]) => {
    const index = mediaList.findIndex(m => m === clickedMedia);
    setLightboxState({
      isOpen: true,
      mediaList,
      currentMedia: clickedMedia,
      currentIndex: index,
    });
  }, []);

  const closeLightbox = useCallback(() => {
    setLightboxState({
      isOpen: false,
      mediaList: [],
      currentMedia: '',
      currentIndex: 0,
    });
  }, []);

  const nextLightboxMedia = useCallback(() => {
    setLightboxState(prev => {
      const nextIndex = (prev.currentIndex + 1) % prev.mediaList.length;
      return {
        ...prev,
        currentMedia: prev.mediaList[nextIndex],
        currentIndex: nextIndex,
      };
    });
  }, []);

  const prevLightboxMedia = useCallback(() => {
    setLightboxState(prev => {
      const prevIndex = (prev.currentIndex - 1 + prev.mediaList.length) % prev.mediaList.length;
      return {
        ...prev,
        currentMedia: prev.mediaList[prevIndex],
        currentIndex: prevIndex,
      };
    });
  }, []);

  // Slider pause state
  const [userPaused, setUserPaused] = useState(false);

  // Render a single product image card for the slider
  const renderProductCard = (item: { src: string; id: number }, onClick: any) => {
    const handleMediaClick = (e: React.MouseEvent) => {
      e.stopPropagation();
      openLightbox(item.src, productImageUrls.map(img => img.src));
    };

    return (
      <div
        className="group cursor-pointer overflow-hidden rounded-xl bg-zinc-100 dark:bg-zinc-800 shadow-lg transition-all hover:scale-[1.02]"
        onClick={(e) => { e.stopPropagation(); handleMediaClick(e); }}
      >
        <div className="relative aspect-square">
          <img
            src={item.src}
            alt={`Product ${item.id}`}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
            <div className="bg-black/60 rounded-full p-2">
              <Maximize2 className="w-5 h-5 text-white" />
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <>
      <style>{`
        @media (max-width: 768px) {
          .mobile-subtitle-container span {
            font-size: 3vw !important;
            letter-spacing: 0.2em !important;
          }
        }
      `}</style>
      <div className="pt-32 pb-20 bg-white dark:bg-zinc-950 transition-colors duration-300">
        <div className="container mx-auto px-6">
          {/* Customer Segments Section */}
          <div className="mobile-subtitle-container">
            <SectionHeading subtitle="Market Presence" title="Customer Segments" centered />
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {customerSegments.map((segment, idx) => (
              <motion.div
                key={segment.title}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="p-8 bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-[3rem] group hover:border-brand-orange/30 transition-all text-center"
              >
                <div className="p-5 bg-brand-orange/10 rounded-2xl w-fit text-brand-orange mb-6 mx-auto group-hover:bg-brand-orange group-hover:text-zinc-950 transition-all">
                  {segment.icon}
                </div>
                <h4 className="text-2xl font-bold text-zinc-950 dark:text-white">{segment.title}</h4>
              </motion.div>
            ))}
          </div>

          {/* Product Portfolio Section */}
          <div className="mt-24">
            <div className="mobile-subtitle-container">
              <SectionHeading subtitle="Our Capabilities" title="Product Portfolio" centered />
            </div>
            <InfiniteSlider
              items={productImageUrls}
              renderCard={renderProductCard}
              baseSpeed={0.8}
              isPaused={userPaused}
              onTogglePause={() => setUserPaused(!userPaused)}
              onItemClick={() => {}} // No modal needed, handled by card click
            />
          </div>
        </div>

        {/* Lightbox */}
        <AnimatePresence>
          {lightboxState.isOpen && (
            <MediaLightbox
              isOpen={lightboxState.isOpen}
              mediaList={lightboxState.mediaList}
              currentMedia={lightboxState.currentMedia}
              currentIndex={lightboxState.currentIndex}
              onClose={closeLightbox}
              onNext={nextLightboxMedia}
              onPrev={prevLightboxMedia}
            />
          )}
        </AnimatePresence>
      </div>
    </>
  );
};

export default Products;
