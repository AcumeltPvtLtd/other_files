import React, { useRef, useState, useEffect, useCallback } from 'react';
import { motion, useMotionValue, useAnimationFrame, AnimatePresence } from 'framer-motion';
import {
  ShieldCheck, Microscope, FlaskConical, Ruler, Activity, CheckCircle2,
  X, ChevronLeft, ChevronRight, Maximize2
} from 'lucide-react';
import { SectionHeading } from '../components/Layout';

// ----------------------------------------------------------------------
// GitHub raw content base URL
// ----------------------------------------------------------------------
const GITHUB_RAW_BASE = 'https://raw.githubusercontent.com/AcumeltPvtLtd/website_images_and_media/main';

// ----------------------------------------------------------------------
// Helper: convert a string to camelCase
// ----------------------------------------------------------------------
const toCamelCase = (str: string): string => {
  return str
    .replace(/[^a-zA-Z0-9]+/g, ' ')
    .trim()
    .split(' ')
    .map((word, index) => {
      if (index === 0) return word.toLowerCase();
      return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
    })
    .join('');
};

// ----------------------------------------------------------------------
// Helper: convert an array of specs to camelCase for both label and value
// ----------------------------------------------------------------------
const convertSpecsToCamelCase = (specs: { label: string; value: string }[]) =>
  specs.map(spec => ({
    label: toCamelCase(spec.label),
    value: toCamelCase(spec.value)
  }));

// ----------------------------------------------------------------------
// Helper: convert camelCase string to human‑readable format
// ----------------------------------------------------------------------
const camelToReadable = (str: string): string => {
  let spaced = str.replace(/_/g, ' ');
  spaced = spaced.replace(/([a-z])([A-Z])/g, '$1 $2');
  spaced = spaced.replace(/([A-Z])([A-Z][a-z])/g, '$1 $2');
  spaced = spaced.replace(/([a-zA-Z])([0-9])/g, '$1 $2');
  spaced = spaced.replace(/([0-9])([a-zA-Z])/g, '$1 $2');
  return spaced
    .split(' ')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
};

// ----------------------------------------------------------------------
// Utility: get images for each quality item
// ----------------------------------------------------------------------
const getItemImages = (item: any) => {
  const mapping: Record<string, string[]> = {
    'Chemical Analysis': [`${GITHUB_RAW_BASE}/quality/spectro.jpg`],
    'Microstructure Analysis': [`${GITHUB_RAW_BASE}/quality/micro.jpg`],
    'Sand Testing': [`${GITHUB_RAW_BASE}/quality/sand-testing-image.webp`],
    'Universal Testing Machine': [`${GITHUB_RAW_BASE}/quality/UTS_Tensile.webp`],
    'Brinell Hardness Tester': [`${GITHUB_RAW_BASE}/quality/Hardness_testing.png`],
    'Ultrasonic Testing': [`${GITHUB_RAW_BASE}/quality/ultrasonic_testing.jpg`],
    'Magnetic Particle Inspection': [`${GITHUB_RAW_BASE}/quality/MPI.jpg`],
    'Impact Testing': [`${GITHUB_RAW_BASE}/quality/izod-charpy-impact-tester.jpg`],
    'CMM': [`${GITHUB_RAW_BASE}/Quality_machine_shop/CMM.png`],
    'Contour Measurement': [`${GITHUB_RAW_BASE}/Quality_machine_shop/contour.jpeg`],
    'Surface Roughness': [`${GITHUB_RAW_BASE}/Quality_machine_shop/surface_roughness_tester.png`],
    'Surface Treatment Inspection': [], // no local media
  };

  const images = mapping[item.title];
  if (images && images.length > 0) {
    return images;
  }

  // Fallback – should not happen for our items except Surface Treatment Inspection
  return [item.image || 'https://picsum.photos/seed/placeholder/800/600'];
};

// ----------------------------------------------------------------------
// Lightbox Component
// ----------------------------------------------------------------------
const MediaLightbox = ({ isOpen, mediaList, currentMedia, currentIndex, onClose, onNext, onPrev }: any) => {
  if (!isOpen) return null;
  const isVideo = currentMedia && currentMedia.endsWith('.mp4');

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black/95 backdrop-blur-lg"
      onClick={onClose}
    >
      <div className="relative w-full h-full flex items-center justify-center pointer-events-none">
        <button
          onClick={(e) => { e.stopPropagation(); onPrev(); }}
          className="absolute left-4 md:left-8 z-20 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all backdrop-blur-md pointer-events-auto border border-white/10"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>

        <div className="relative max-w-[90vw] max-h-[90vh] pointer-events-auto">
          {isVideo ? (
            <video
              src={currentMedia}
              autoPlay
              muted
              loop
              playsInline
              controls
              className="max-w-full max-h-[90vh] object-contain rounded-lg shadow-2xl"
            />
          ) : (
            <img
              src={currentMedia}
              alt="Lightbox media"
              className="max-w-full max-h-[90vh] object-contain rounded-lg shadow-2xl"
            />
          )}
        </div>

        <button
          onClick={(e) => { e.stopPropagation(); onNext(); }}
          className="absolute right-4 md:right-8 z-20 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all backdrop-blur-md pointer-events-auto border border-white/10"
        >
          <ChevronRight className="w-6 h-6" />
        </button>

        <button
          onClick={(e) => { e.stopPropagation(); onClose(); }}
          className="absolute top-4 right-4 md:top-8 md:right-8 z-20 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all backdrop-blur-md pointer-events-auto border border-white/10"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 bg-black/60 backdrop-blur-md px-4 py-2 rounded-full text-white text-sm font-mono pointer-events-auto">
          {currentIndex + 1} / {mediaList.length}
        </div>
      </div>
    </motion.div>
  );
};

// ----------------------------------------------------------------------
// Detail Modal Component (Media Hub) – extended to support video & gallery
// ----------------------------------------------------------------------
const DetailModal = ({ item, currentIndex, totalItems, onNext, onPrev, onClose, hideText, onOpenLightbox }: any) => {
  if (!item) return null;

  const hasSpecs = 'specs' in item && Array.isArray(item.specs);
  const hasFeatures = 'features' in item && Array.isArray(item.features);
  const hasDesc = 'desc' in item;
  const hasFooter = 'footer' in item && item.footer;
  const images = getItemImages(item);
  const hasMedia = item.video || images.length > 0;

  const handleMediaClick = (mediaUrl: string, e: React.MouseEvent) => {
    e.stopPropagation();
    onOpenLightbox(item, mediaUrl);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl"
      onClick={onClose}
    >
      <div className="relative flex items-center justify-center w-full max-w-6xl h-full pointer-events-none">
        {/* Navigation - Previous */}
        <button
          onClick={(e) => { e.stopPropagation(); onPrev(); }}
          className="absolute left-0 lg:-left-12 z-30 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all backdrop-blur-md pointer-events-auto border border-white/10 hidden md:block"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>

        <motion.div
          key={item.title}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="relative max-w-4xl w-full max-h-[90vh] overflow-y-auto bg-white dark:bg-zinc-950 rounded-[2rem] shadow-2xl border border-zinc-200 dark:border-zinc-800 pointer-events-auto"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Internal Navigation Controls for Mobile */}
          <div className="sticky top-0 right-0 flex justify-between items-center p-3 z-30 md:p-4 pointer-events-none">
            <div className="flex items-center gap-2 pointer-events-auto bg-black/60 backdrop-blur-md py-1 px-3 rounded-full border border-white/10 text-white/90">
              <span className="text-[9px] font-black uppercase tracking-wider">Item {currentIndex + 1} / {totalItems}</span>
            </div>
            <div className="flex gap-2 pointer-events-auto">
              <button
                onClick={(e) => { e.stopPropagation(); onPrev(); }}
                className="p-2 rounded-full bg-black/60 backdrop-blur-md hover:bg-black/80 text-white transition-all md:hidden border border-white/10"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={(e) => { e.stopPropagation(); onNext(); }}
                className="p-2 rounded-full bg-black/60 backdrop-blur-md hover:bg-black/80 text-white transition-all md:hidden border border-white/10"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
              <button
                onClick={onClose}
                className="p-2 rounded-full bg-brand-orange hover:scale-110 text-white transition-all shadow-lg border border-orange-400/20"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="px-6 pb-10 pt-2 md:px-10 md:pb-12">
            {hasMedia && (
              <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-8">
                <div className="md:col-span-3 relative aspect-video rounded-2xl overflow-hidden bg-zinc-900 shadow-lg border border-zinc-800 cursor-pointer group">
                  <div onClick={(e) => handleMediaClick(item.video || images[0], e)} className="w-full h-full">
                    {item.video ? (
                      item.video.endsWith('.mp4') ? (
                        <video
                          src={item.video}
                          autoPlay
                          muted
                          loop
                          playsInline
                          key={item.video}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <img
                          src={item.video}
                          alt={item.title}
                          className="w-full h-full object-cover"
                        />
                      )
                    ) : (
                      <img
                        src={images[0]}
                        alt={item.title}
                        className="w-full h-full object-cover"
                      />
                    )}
                    <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
                      <div className="bg-black/60 rounded-full p-2">
                        <Maximize2 className="w-5 h-5 text-white" />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="md:col-span-2 grid grid-cols-2 gap-3">
                  {images.map((img: string, idx: number) => (
                    <div
                      key={idx}
                      className={`rounded-xl overflow-hidden bg-zinc-800 shadow-md cursor-pointer group ${idx === 0 ? 'col-span-2 aspect-[2/1]' : 'aspect-square'}`}
                      onClick={(e) => handleMediaClick(img, e)}
                    >
                      <img
                        src={img}
                        alt={`${item.title} ${idx + 1}`}
                        className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-500"
                      />
                      <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
                        <div className="bg-black/60 rounded-full p-1.5">
                          <Maximize2 className="w-3 h-3 text-white" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {!hideText && (
              <>
                <div className="flex items-start gap-4 mb-6">
                  <div className="text-brand-orange bg-brand-orange/10 p-3 rounded-xl shrink-0">
                    {React.cloneElement(item.icon as React.ReactElement, { className: "w-7 h-7" })}
                  </div>
                  <div>
                    <h2 className="text-xl md:text-1xl font-black dark:text-white leading-tight mb-1">{item.title}</h2>
                    {item.subtitle && (
                      <p className="text-zinc-500 text-[10px] font-black uppercase tracking-[0.2em] opacity-80">
                        {item.subtitle}
                      </p>
                    )}
                  </div>
                </div>

                {hasDesc && <p className="text-base text-zinc-600 dark:text-zinc-400 mb-8 leading-relaxed font-medium">{item.desc}</p>}

                {hasSpecs && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-zinc-50 dark:bg-zinc-900/50 p-6 rounded-[1.5rem] border border-zinc-200 dark:border-zinc-800 mb-8">
                    {item.specs.map((spec: any, idx: number) => (
                      <div key={idx} className="flex flex-col border-l-2 border-brand-orange/40 pl-4">
                        <p className="text-[10px] text-zinc-500 font-black uppercase tracking-wider mb-0.5">{camelToReadable(spec.label)}</p>
                        <p className="text-sm font-bold dark:text-zinc-200">{camelToReadable(spec.value)}</p>
                      </div>
                    ))}
                  </div>
                )}

                {hasFooter && (
                  <div className="mt-6 pt-6 border-t border-zinc-200 dark:border-zinc-800">
                    <p className="text-[10px] text-zinc-500 dark:text-zinc-500 uppercase tracking-widest leading-relaxed">
                      {item.footer}
                    </p>
                  </div>
                )}

                {hasFeatures && (
                  <div className="space-y-3">
                    <p className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-400 mb-4">Capabilities & Compliance</p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {item.features.map((feature: string, idx: number) => (
                        <motion.div
                          key={idx}
                          initial={{ opacity: 0, y: 5 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: idx * 0.04 }}
                          className="flex items-center gap-3 text-xs font-bold dark:text-zinc-300 bg-white dark:bg-zinc-900/80 p-3 rounded-xl border border-zinc-200 dark:border-zinc-800 shadow-sm"
                        >
                          <CheckCircle2 className="w-4 h-4 text-brand-orange shrink-0" />
                          <span>{feature}</span>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        </motion.div>

        {/* Navigation - Next */}
        <button
          onClick={(e) => { e.stopPropagation(); onNext(); }}
          className="absolute right-0 lg:-right-12 z-30 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all backdrop-blur-md pointer-events-auto border border-white/10 hidden md:block"
        >
          <ChevronRight className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};

// ----------------------------------------------------------------------
// Infinite Slider (as in Infrastructure.tsx)
// ----------------------------------------------------------------------
const InfiniteSlider = ({ items, renderCard, baseSpeed = 1, isPaused, onTogglePause, onItemClick }: any) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const x = useMotionValue(0);
  const [isDragging, setIsDragging] = useState(false);
  const [contentWidth, setContentWidth] = useState(0);
  const justDragged = useRef(false);

  const duplicatedItems = [...items, ...items, ...items];

  useEffect(() => {
    if (contentRef.current) setContentWidth(contentRef.current.scrollWidth / 3);
  }, [items]);

  useAnimationFrame((_, delta) => {
    if (isPaused || isDragging || contentWidth === 0) return;
    const deltaMove = baseSpeed * (delta / 10);
    let newX = x.get() - deltaMove;
    newX = ((newX % contentWidth) + contentWidth) % contentWidth - contentWidth;
    x.set(newX);
  });

  const handleDragStart = () => { setIsDragging(true); justDragged.current = true; };
  const handleDragEnd = () => { setIsDragging(false); setTimeout(() => { justDragged.current = false; }, 100); };

  const handleContainerClick = () => {
    if (!justDragged.current) onTogglePause();
  };

  return (
    <div
      ref={containerRef}
      className="relative overflow-hidden py-10 cursor-grab active:cursor-grabbing"
      onClick={handleContainerClick}
    >
      <motion.div
        ref={contentRef}
        className={`flex gap-8 ${isDragging ? 'pointer-events-none' : ''}`}
        style={{ x }}
        drag="x"
        onDragStart={handleDragStart}
        onDragEnd={handleDragEnd}
        dragElastic={0.05}
        dragMomentum={false}
      >
        {duplicatedItems.map((item, idx) => (
          <div key={idx} className="flex-shrink-0 w-[85vw] md:w-[500px] select-none">
            {renderCard(item, (it: any) => onItemClick(it, items))}
          </div>
        ))}
      </motion.div>
    </div>
  );
};

// ----------------------------------------------------------------------
// Main Component
// ----------------------------------------------------------------------
const Quality = () => {
  // ----- Data with camelCase specs and local media URLs -----
  const foundryEquipment = [
    {
      title: 'Chemical Analysis',
      subtitle: 'Ametek SpectroMaxX',
      icon: <FlaskConical className="w-8 h-8" />,
      image: `${GITHUB_RAW_BASE}/quality/spectro.jpg`,
      video: `${GITHUB_RAW_BASE}/quality/spectro.jpg`, // same as image (no video)
      specs: convertSpecsToCamelCase([
        { label: 'Elements', value: '24 Elements' },
        { label: 'Range', value: 'Wavelength Range 120-670 nm' },
        { label: 'Calibration', value: 'Easy auto calibration of equipment' },
        { label: 'Diagnosis', value: 'Auto fault diagnosis system' },
        { label: 'Cooling', value: 'Auto optical cooling' }
      ])
    },
    {
      title: 'Microstructure Analysis',
      subtitle: 'Olympus GX53F Microscope',
      icon: <Microscope className="w-8 h-8" />,
      image: `${GITHUB_RAW_BASE}/quality/micro.jpg`,
      video: `${GITHUB_RAW_BASE}/quality/micro.jpg`,
      specs: convertSpecsToCamelCase([
        { label: 'Image Analysis', value: 'Computerized, cast iron module' },
        { label: 'Nodule count', value: 'Count, Flask size, type, distribution' },
        { label: 'Distribution', value: 'Pearlite/Ferrite distribution' },
        { label: 'Imaging', value: 'EFI Extended Focal Imaging' },
        { label: 'Resolution', value: 'Multi-plane image stitching' }
      ])
    },
    {
      title: 'Sand Testing',
      subtitle: 'Versatile Sand Testing Equipment',
      icon: <Activity className="w-8 h-8" />,
      image: `${GITHUB_RAW_BASE}/quality/sand-testing-image.webp`,
      video: `${GITHUB_RAW_BASE}/quality/sand-testing-image.webp`,
      specs: convertSpecsToCamelCase([
        { label: 'Capabilities', value: 'Compactibility, Moisture, Permeability' },
        { label: 'Universal Strength', value: 'Tensile, Compressibility, Shear' },
        { label: 'Green Strength', value: 'Green Compression Strength' },
        { label: 'Hardness', value: 'Core Hardness, Mold Hardness' },
        { label: 'Distribution', value: 'Grain Size Distribution' },
        { label: 'Specialized', value: 'Wet/Hot Tensile, Flowability' }
      ])
    },
    {
      title: 'Universal Testing Machine',
      subtitle: 'UTES HGFL 40',
      icon: <Activity className="w-8 h-8" />,
      image: `${GITHUB_RAW_BASE}/quality/UTS_Tensile.webp`,
      video: `${GITHUB_RAW_BASE}/quality/UTS_Tensile.webp`,
      specs: convertSpecsToCamelCase([
        { label: 'Capacity', value: '400 kN' },
        { label: 'Control', value: 'Computerized with data acquisition' },
        { label: 'Extensometer', value: 'Model: EE-2 (25mm, 50mm, 70mm)' },
        { label: 'Tests', value: 'Tensile, Compression, Transverse, Bend' },
        { label: 'Accuracy', value: 'Class 1 as per ISO 7500-1' }
      ])
    },
    {
      title: 'Brinell Hardness Tester',
      subtitle: 'FIE Model: B 3000-PC',
      icon: <Ruler className="w-8 h-8" />,
      image: `${GITHUB_RAW_BASE}/quality/Hardness_testing.png`,
      video: `${GITHUB_RAW_BASE}/quality/Hardness_testing.png`,
      specs: convertSpecsToCamelCase([
        { label: 'Test Loads', value: '500 kgf to 3000 kgf' },
        { label: 'Indenter', value: '5mm & 10mm Tungsten Carbide Ball' },
        { label: 'Measurement', value: 'Optical microscope with digital readout' },
        { label: 'Standards', value: 'ASTM E10 / ISO 6506' }
      ])
    },
    {
      title: 'Ultrasonic Testing',
      subtitle: 'Modosonic Instruments (ARJUN 30)',
      icon: <ShieldCheck className="w-8 h-8" />,
      image: `${GITHUB_RAW_BASE}/quality/ultrasonic_testing.jpg`,
      video: `${GITHUB_RAW_BASE}/quality/ultrasonic_testing.jpg`,
      specs: convertSpecsToCamelCase([
        { label: 'Test Range', value: '2.5mm to 10 meter' },
        { label: 'Velocity', value: '1000 to 15000 met/sec' },
        { label: 'Rectification', value: 'Full-wave rectified with filtering' },
        { label: 'Frequency', value: 'Broad Band 0.5 MHz to 15Mhz' },
        { label: 'Linearity', value: 'V: +3%, H: +0.5%' }
      ])
    },
    {
      title: 'Magnetic Particle Inspection',
      subtitle: 'Yoke Type MPI Machine',
      icon: <ShieldCheck className="w-8 h-8" />,
      image: `${GITHUB_RAW_BASE}/quality/MPI.jpg`,
      video: `${GITHUB_RAW_BASE}/quality/MPI.jpg`,
      specs: convertSpecsToCamelCase([
        { label: 'Equipment', value: 'AC/DC Magnetic Yoke' },
        { label: 'Detection', value: 'Surface & Sub-surface cracks' },
        { label: 'Method', value: 'Dry & Wet Fluorescent' },
        { label: 'Portability', value: 'Handheld for field inspection' },
        { label: 'Standards', value: 'ASTM E1444 / ISO 9934' }
      ])
    },
    {
      title: 'Impact Testing',
      subtitle: 'FIE Charpy Impact Tester',
      icon: <Activity className="w-8 h-8" />,
      image: `${GITHUB_RAW_BASE}/quality/izod-charpy-impact-tester.jpg`,
      video: `${GITHUB_RAW_BASE}/quality/izod-charpy-impact-tester.jpg`,
      specs: convertSpecsToCamelCase([
        { label: 'Equipment', value: 'FIE Impact Testing Machine' },
        { label: 'Energy Range', value: '0-300 Joules' },
        { label: 'Test Type', value: 'Charpy V-Notch / Izod' },
        { label: 'Accuracy', value: 'High precision pendulum system' },
        { label: 'Standards', value: 'ASTM E23 / ISO 148-1' }
      ])
    }
  ];

  const machineShopEquipment = [
    {
      title: 'CMM',
      subtitle: 'CRYSTA Apex V 7106 PH10MQ SP25',
      icon: <Ruler className="w-8 h-8" />,
      image: `${GITHUB_RAW_BASE}/Quality_machine_shop/CMM.png`,
      video: `${GITHUB_RAW_BASE}/Quality_machine_shop/CMM.png`,
      specs: convertSpecsToCamelCase([
        { label: 'Range (X/Y/Z)', value: '700 x 1000 x 600 mm' },
        { label: 'Resolution', value: '0.1 µm' },
        { label: 'Accuracy', value: '(1.7+3 L/1000)µm (ISO10360-2)' },
        { label: 'Repeatability', value: '1.3µm' },
        { label: 'Temp Comp', value: '16° to 26°C range' },
        { label: 'Performance', value: '519 mm/s Speed, 2309 mm/s² Accel' }
      ])
    },
    {
      title: 'Contour Measurement',
      subtitle: 'Contracer CV2100 M4',
      icon: <Activity className="w-8 h-8" />,
      image: `${GITHUB_RAW_BASE}/Quality_machine_shop/contour.jpeg`,
      video: `${GITHUB_RAW_BASE}/Quality_machine_shop/contour.jpeg`,
      specs: convertSpecsToCamelCase([
        { label: 'Measuring Range', value: 'X: 100mm, Z1: 50mm' },
        { label: 'Column Travel', value: '350mm Vertical' },
        { label: 'Linear Accuracy', value: '2.5μm/100mm' },
        { label: 'Resolution', value: '0.1μm (X & Z1)' },
        { label: 'X Accuracy', value: '±(2.5 + 0.02L)µm' },
        { label: 'Z1 Accuracy', value: '±(2.5 + |0.1H|)µm' }
      ])
    },
    {
      title: 'Surface Roughness',
      subtitle: 'Surftest SJ 220 (4mN)',
      icon: <CheckCircle2 className="w-8 h-8" />,
      image: `${GITHUB_RAW_BASE}/Quality_machine_shop/surface_roughness_tester.png`,
      video: `${GITHUB_RAW_BASE}/Quality_machine_shop/surface_roughness_tester.png`,
      specs: convertSpecsToCamelCase([
        { label: 'Measuring Range', value: 'X: 17.5mm, Z: 360 µm' },
        { label: 'Resolution', value: '0.0002µm (min)' },
        { label: 'Stylus', value: '90°/ 5µm; 4mN force' },
        { label: 'Standards', value: 'ISO 4287, ISO 13565, ISO 21920' },
        { label: 'Profiles', value: 'Primary (P), Roughness (R), DF, R-Motif' },
        { label: 'Cut-off (λc)', value: '0.08 / 0.25 / 0.8 / 2.5 / 8 mm' }
      ])
    }
  ];

  const surfaceTreatmentEquipment = [
    {
      title: 'Surface Treatment Inspection',
      subtitle: 'Coating Quality Control',
      icon: <CheckCircle2 className="w-8 h-8" />,
      image: 'https://images.unsplash.com/photo-1581091226033-d5c48150dbaa?w=800&h=600&fit=crop',
      // video intentionally undefined – no media
      specs: convertSpecsToCamelCase([
        { label: 'Dry film thickness', value: 'Magnetic or eddy current coating thickness gauge' },
        { label: 'Adhesion of coating', value: 'Cross-cut adhesion test' },
        { label: 'Corrosion resistance', value: 'Neutral salt spray test' },
        { label: 'Hardness of coating', value: 'Pencil hardness test' },
        { label: 'Impact resistance', value: 'Falling weight impact test' },
        { label: 'Gloss level', value: 'Gloss meter measurement' },
        { label: 'Flexibility of coating', value: 'Mandrel bend test' },
        { label: 'Abrasion resistance', value: 'Taber abrasion test' },
        { label: 'Blistering of coating', value: 'Visual evaluation' },
        { label: 'Rusting after corrosion test', value: 'Visual evaluation' }
      ]),
      footer: 'Standards followed: ISO 2808, ASTM D7091, ISO 2409, ASTM D3359, ASTM B117, ISO 9227, ASTM D3363, ISO 15184, ASTM D2794, ISO 6272, ASTM D523, ISO 2813, ASTM D522, ISO 6860, ASTM D4060, ISO 7784, ASTM D714, ASTM D610'
    }
  ];

  // ----- Modal and lightbox state -----
  const [modalContext, setModalContext] = useState<any>(null);
  const [userPaused, setUserPaused] = useState(false);
  const [modalPaused, setModalPaused] = useState(false);

  const [lightboxState, setLightboxState] = useState<{
    isOpen: boolean;
    mediaList: string[];
    currentMedia: string;
    currentIndex: number;
  }>({
    isOpen: false,
    mediaList: [],
    currentMedia: '',
    currentIndex: 0,
  });

  const openLightbox = useCallback((item: any, clickedMedia: string) => {
    const mediaList = getItemImages(item);
    // Include main video if exists and not already in list
    const fullMediaList = item.video && !mediaList.includes(item.video) ? [item.video, ...mediaList] : mediaList;
    const index = fullMediaList.findIndex(m => m === clickedMedia);
    if (index !== -1 && fullMediaList.length > 0) {
      setLightboxState({
        isOpen: true,
        mediaList: fullMediaList,
        currentMedia: clickedMedia,
        currentIndex: index,
      });
    }
  }, []);

  const closeLightbox = useCallback(() => {
    setLightboxState({
      isOpen: false,
      mediaList: [],
      currentMedia: '',
      currentIndex: 0,
    });
  }, []);

  const nextLightboxMedia = useCallback(() => {
    setLightboxState(prev => {
      if (prev.mediaList.length === 0) return prev;
      const nextIndex = (prev.currentIndex + 1) % prev.mediaList.length;
      return {
        ...prev,
        currentMedia: prev.mediaList[nextIndex],
        currentIndex: nextIndex,
      };
    });
  }, []);

  const prevLightboxMedia = useCallback(() => {
    setLightboxState(prev => {
      if (prev.mediaList.length === 0) return prev;
      const prevIndex = (prev.currentIndex - 1 + prev.mediaList.length) % prev.mediaList.length;
      return {
        ...prev,
        currentMedia: prev.mediaList[prevIndex],
        currentIndex: prevIndex,
      };
    });
  }, []);

  const openModal = useCallback((item: any, section: any[]) => {
    const idx = section.findIndex(i => i.title === item.title);
    setModalContext({ item, section, index: idx, hideText: false });
    setModalPaused(true);
  }, []);

  const nextModalItem = useCallback(() => {
    if (!modalContext) return;
    const { section, index } = modalContext;
    const nextIdx = (index + 1) % section.length;
    setModalContext({ ...modalContext, item: section[nextIdx], index: nextIdx });
  }, [modalContext]);

  const prevModalItem = useCallback(() => {
    if (!modalContext) return;
    const { section, index } = modalContext;
    const prevIdx = (index - 1 + section.length) % section.length;
    setModalContext({ ...modalContext, item: section[prevIdx], index: prevIdx });
  }, [modalContext]);

  const closeModal = useCallback(() => {
    setModalContext(null);
    setModalPaused(false);
  }, []);

  // ----- Card renderers with clickable media -----
  const SpecCard = (item: any, onCardClick: any) => {
    const handleMediaClick = (e: React.MouseEvent) => {
      e.stopPropagation();
      if (item.video) openLightbox(item, item.video);
      else if (item.image) openLightbox(item, item.image);
    };

    return (
      <div
        className="h-full bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-[2.5rem] overflow-hidden shadow-md cursor-pointer transition-all hover:scale-[1.02] hover:border-brand-orange/50 hover:shadow-xl"
        onClick={(e) => { e.stopPropagation(); onCardClick(item); }}
      >
        <div className="relative aspect-video cursor-pointer group" onClick={handleMediaClick}>
          <img
            src={item.video || item.image}
            alt={item.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
            <div className="bg-black/60 rounded-full p-2">
              <Maximize2 className="w-5 h-5 text-white" />
            </div>
          </div>
          <div className="absolute inset-0 bg-gradient-to-t from-zinc-50 dark:from-zinc-900 to-transparent opacity-40 pointer-events-none" />
        </div>
        <div className="p-8 text-center">
          <div className="text-brand-orange mb-4 flex justify-center">{item.icon}</div>
          <h4 className="text-lg font-bold dark:text-white">{item.title}</h4>
          <p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest mb-6">{item.subtitle}</p>
          <div className="space-y-2 mt-4 text-left">
            {item.specs.map((spec: any, i: number) => (
              <div key={i} className="flex justify-between items-baseline gap-4">
                <span className="font-bold text-zinc-600 dark:text-zinc-400 text-xs flex-shrink-0">
                  {camelToReadable(spec.label)}:
                </span>
                <span className="text-zinc-700 dark:text-zinc-300 text-xs text-right break-words">
                  {camelToReadable(spec.value)}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  };

  const TreatmentCard = (item: any, onCardClick: any) => {
    const handleMediaClick = (e: React.MouseEvent) => {
      e.stopPropagation();
      if (item.video) openLightbox(item, item.video);
      else if (item.image) openLightbox(item, item.image);
    };

    return (
      <div
        className="h-full bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-[2.5rem] p-8 flex flex-col md:flex-row gap-8 items-center shadow-md cursor-pointer transition-all hover:scale-[1.02] hover:border-brand-orange/50 hover:shadow-xl"
        onClick={(e) => { e.stopPropagation(); onCardClick(item); }}
      >
        <div className="w-full md:w-1/3 aspect-square rounded-2xl overflow-hidden shrink-0 cursor-pointer group" onClick={handleMediaClick}>
          <img
            src={item.video || item.image}
            alt={item.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
            <div className="bg-black/60 rounded-full p-2">
              <Maximize2 className="w-5 h-5 text-white" />
            </div>
          </div>
        </div>
        <div className="flex-1">
          <div className="text-brand-orange mb-3">{item.icon}</div>
          <h4 className="text-lg font-bold dark:text-white">{item.title}</h4>
          <p className="text-zinc-600 dark:text-zinc-400 text-sm my-4 leading-relaxed line-clamp-2">{item.subtitle}</p>
          <div className="space-y-2 mt-4">
            {item.specs.map((spec: any, i: number) => (
              <div key={i} className="flex justify-between items-baseline gap-4">
                <span className="font-bold text-zinc-600 dark:text-zinc-400 text-xs flex-shrink-0">
                  {camelToReadable(spec.label)}:
                </span>
                <span className="text-zinc-700 dark:text-zinc-300 text-xs text-right break-words">
                  {camelToReadable(spec.value)}
                </span>
              </div>
            ))}
          </div>
          {item.footer && (
            <div className="mt-6 pt-4 border-t border-zinc-200 dark:border-zinc-800">
              <p className="text-[9px] text-zinc-500 uppercase tracking-widest leading-relaxed line-clamp-2">
                {item.footer}
              </p>
            </div>
          )}
        </div>
      </div>
    );
  };

  // ----- Surface Treatment card (static, text only – no image) -----
  const StaticSurfaceCard = () => (
    <div className="max-w-4xl mx-auto py-10">
      {surfaceTreatmentEquipment.map((item, idx) => (
        <div key={idx} className="bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-[2.5rem] p-8">
          <div className="text-brand-orange mb-3">{item.icon}</div>
          <h4 className="text-lg font-bold dark:text-white">{item.title}</h4>
          <p className="text-zinc-600 dark:text-zinc-400 text-sm my-4 leading-relaxed">{item.subtitle}</p>
          <div className="space-y-2 mt-4">
            {item.specs.map((spec: any, i: number) => (
              <div key={i} className="flex justify-between items-baseline gap-4">
                <span className="font-bold text-zinc-600 dark:text-zinc-400 text-xs flex-shrink-0">
                  {camelToReadable(spec.label)}:
                </span>
                <span className="text-zinc-700 dark:text-zinc-300 text-xs text-right break-words">
                  {camelToReadable(spec.value)}
                </span>
              </div>
            ))}
          </div>
          {item.footer && (
            <div className="mt-6 pt-4 border-t border-zinc-200 dark:border-zinc-800">
              <p className="text-[9px] text-zinc-500 uppercase tracking-widest leading-relaxed">
                {item.footer}
              </p>
            </div>
          )}
        </div>
      ))}
    </div>
  );

  return (
    <>
      <style>{`
        @media (max-width: 768px) {
          .mobile-subtitle-container span {
            font-size: 3vw !important;
            letter-spacing: 0.2em !important;
          }
        }
      `}</style>
      <div className="pt-32 pb-20 bg-white dark:bg-zinc-950 transition-colors duration-300 overflow-hidden">
        <div className="container mx-auto px-6">
          {/* Foundry & Heat Treatment */}
          <section className="mb-24">
            <div className="mobile-subtitle-container">
              <SectionHeading subtitle="Quality Control" title="Foundry & Heat Treatment" centered />
            </div>
            <InfiniteSlider
              items={foundryEquipment}
              renderCard={SpecCard}
              baseSpeed={1.2}
              isPaused={userPaused || modalPaused}
              onTogglePause={() => setUserPaused(!userPaused)}
              onItemClick={openModal}
            />
          </section>

          {/* Machine Shop */}
          <section className="mb-24">
            <div className="mobile-subtitle-container">
              <SectionHeading subtitle="Quality Control" title="Machine Shop" centered />
            </div>
            <InfiniteSlider
              items={machineShopEquipment}
              renderCard={SpecCard}
              baseSpeed={1.2}
              isPaused={userPaused || modalPaused}
              onTogglePause={() => setUserPaused(!userPaused)}
              onItemClick={openModal}
            />
          </section>

          {/* Surface Treatment – Static Card (text only) */}
          <section className="mb-24">
            <div className="mobile-subtitle-container">
              <SectionHeading subtitle="Quality Control" title="Surface Treatment" centered />
            </div>
            <StaticSurfaceCard />
          </section>
        </div>

        <AnimatePresence>
          {modalContext && (
            <DetailModal
              item={modalContext.item}
              currentIndex={modalContext.index}
              totalItems={modalContext.section.length}
              onNext={nextModalItem}
              onPrev={prevModalItem}
              onClose={closeModal}
              hideText={false}
              onOpenLightbox={openLightbox}
            />
          )}
          {lightboxState.isOpen && (
            <MediaLightbox
              isOpen={lightboxState.isOpen}
              mediaList={lightboxState.mediaList}
              currentMedia={lightboxState.currentMedia}
              currentIndex={lightboxState.currentIndex}
              onClose={closeLightbox}
              onNext={nextLightboxMedia}
              onPrev={prevLightboxMedia}
            />
          )}
        </AnimatePresence>
      </div>
    </>
  );
};

export default Quality;
