import React from 'react';
import { motion } from 'framer-motion';
import { Target, Eye, AlertTriangle, CheckCircle2, ArrowDown } from 'lucide-react';
import { SectionHeading } from '../components/Layout';

const About = () => {
  return (
    <>
      <style>{`
        @media (max-width: 768px) {
          .mobile-subtitle-container span {
            font-size: 3vw !important;
            letter-spacing: 0.2em !important;
          }
        }
      `}</style>
      <div className="pt-32 pb-20 bg-white dark:bg-zinc-950 transition-colors duration-300">
        <div className="container mx-auto px-6">
          <div className="mobile-subtitle-container">
            <SectionHeading subtitle="Company Profile" title="About Acumelt" centered />
          </div>
          
          <div className="grid lg:grid-cols-2 gap-20 mb-32">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="space-y-8 text-zinc-600 dark:text-zinc-400 text-xl font-light leading-relaxed"
            >
              <p className="text-justify">
                Acumelt Private Limited manufactures ductile iron components designed for demanding engineering applications, with a focus on metallurgical control, dimensional accuracy, and consistent product quality.
              </p>
              <p className="text-justify">
                The facility operates a fully integrated process chain including casting, machining, heat treatment, and surface finishing such as liquid painting and powder coating.
              </p>
              <p className="text-justify">
                Consolidating these processes in-house enables tighter process control, improved traceability, reduced handling and logistics, and optimized production efficiency, resulting in improved reliability and cost effectiveness for the end customer.
              </p>
              <p className="text-justify">
                Acumelt is endowed with numerous resources such as state of the art physical infrastructure & highly experienced and capable personnel.
              </p>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="bg-zinc-50 dark:bg-zinc-900/50 border border-zinc-200 dark:border-zinc-800 p-8 rounded-[2.5rem] relative overflow-hidden h-full flex flex-col justify-center"
            >
              <div className="absolute top-0 right-0 w-64 h-64 bg-brand-orange/5 blur-[150px]" />
              <img 
                src="https://raw.githubusercontent.com/AcumeltPvtLtd/website_images_and_media/main/plant2.jpeg"
                alt=""
                className="absolute bottom-0 right-0 w-32 h-32 object-cover opacity-10 pointer-events-none"
                referrerPolicy="no-referrer"
              />
              <h4 className="text-brand-orange font-black text-xs uppercase tracking-[0.3em] mb-8">Capacity Breakdown</h4>
              <div className="space-y-10">
                {[
                  { label: 'Installed Capacity', value: '12,000 Tons', color: 'bg-zinc-200 dark:bg-zinc-800' },
                  { label: 'Utilized Capacity', value: '5,000 Tons', color: 'bg-brand-orange/20' },
                  { label: 'Total Free for Business', value: '7,000 Tons', color: 'bg-brand-orange' },
                ].map((item, idx) => (
                  <div key={item.label} className="relative">
                    <div className="flex justify-between items-end mb-2">
                      <span className="text-zinc-500 dark:text-zinc-400 font-bold uppercase text-sm tracking-widest">{item.label}</span>
                      <span className="text-zinc-950 dark:text-white font-black text-xl">{item.value}</span>
                    </div>
                    <div className="h-2 w-full bg-zinc-200 dark:bg-zinc-800 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        whileInView={{ width: '100%' }}
                        viewport={{ once: true }}
                        transition={{ delay: idx * 0.1, duration: 1 }}
                        className={`h-full ${item.color}`}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Capabilities Legend */}
          <div className="flex flex-wrap justify-center items-center gap-x-12 gap-y-6 pt-8 mb-32 border-t border-zinc-100 dark:border-zinc-900">
            {['CASTING', 'MACHINING', 'HEAT TREATMENT', 'SURFACE TREATMENT'].map((text) => (
              <span key={text} className="text-zinc-950 dark:text-white font-black text-sm tracking-[0.4em] hover:text-brand-orange transition-colors cursor-default">
                {text}
              </span>
            ))}
          </div>

          <div className="grid md:grid-cols-2 gap-12 mb-32">
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="relative p-12 bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-[3rem] group hover:border-brand-orange/30 transition-all text-center overflow-hidden"
            >
              <img 
                src="https://raw.githubusercontent.com/AcumeltPvtLtd/website_images_and_media/main/core_shop/core_shop1.jpeg"
                alt=""
                className="absolute inset-0 w-full h-full object-cover opacity-10 pointer-events-none"
                referrerPolicy="no-referrer"
              />
              <div className="relative z-10">
                <div className="p-5 bg-brand-orange/10 rounded-2xl mx-auto text-brand-orange mb-8 group-hover:bg-brand-orange group-hover:text-zinc-950 transition-all w-fit">
                  <Eye className="w-10 h-10" />
                </div>
                <h4 className="text-3xl font-bold text-zinc-950 dark:text-white mb-6">Vision Statement</h4>
                <p className="text-zinc-600 dark:text-zinc-400 text-lg font-light leading-relaxed">
                  To be a globally respected manufacturer of ductile iron cast components, driven by innovation, automation, and sustainable practices.
                </p>
              </div>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="relative p-12 bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-[3rem] group hover:border-brand-orange/30 transition-all text-center overflow-hidden"
            >
              <video 
                autoPlay loop muted playsInline
                className="absolute inset-0 w-full h-full object-cover opacity-10 pointer-events-none"
                src="https://raw.githubusercontent.com/AcumeltPvtLtd/website_images_and_media/main/pouring/70349.mp4"
              />
              <div className="relative z-10">
                <div className="p-5 bg-brand-orange/10 rounded-2xl mx-auto text-brand-orange mb-8 group-hover:bg-brand-orange group-hover:text-zinc-950 transition-all w-fit">
                  <Target className="w-10 h-10" />
                </div>
                <h4 className="text-3xl font-bold text-zinc-950 dark:text-white mb-6">Mission Statement</h4>
                <p className="text-zinc-600 dark:text-zinc-400 text-lg font-light leading-relaxed">
                  To deliver high-quality, reliable, and competitive ductile iron cast components through continuous improvement and responsible growth.
                </p>
              </div>
            </motion.div>
          </div>

          {/* RE-ALIGNED Infrastructure Section */}
          <div className="mb-32">
            <div className="mobile-subtitle-container">
              <SectionHeading subtitle="Infrastructure" title="Land Use & Facility" centered />
            </div>
            <div className="flex flex-wrap justify-center gap-10">
              {/* Card 1 */}
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="relative aspect-video rounded-[3rem] overflow-hidden border border-zinc-200 dark:border-zinc-800 w-full md:w-[calc(50%-1.25rem)] lg:max-w-xl group"
              >
                <img 
                  src="https://raw.githubusercontent.com/AcumeltPvtLtd/website_images_and_media/main/melting/1.jpeg" 
                  alt="Factory" 
                  className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/80 via-zinc-950/20 to-transparent" />
                <div className="absolute bottom-10 left-10 z-10">
                  <div className="text-brand-orange font-black text-5xl lg:text-6xl mb-2">41,300 <span className="text-2xl">m²</span></div>
                  <div className="text-white font-black text-xs uppercase tracking-[0.3em]">Total Land Area</div>
                </div>
              </motion.div>

              {/* Card 2 */}
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 }}
                className="relative aspect-video rounded-[3rem] overflow-hidden border border-zinc-200 dark:border-zinc-800 w-full md:w-[calc(50%-1.25rem)] lg:max-w-xl group"
              >
                <img 
                  src="https://raw.githubusercontent.com/AcumeltPvtLtd/website_images_and_media/main/pouring/70358.jpeg" 
                  alt="Factory Floor" 
                  className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/80 via-zinc-950/20 to-transparent" />
                <div className="absolute bottom-10 left-10 z-10">
                  <div className="text-brand-orange font-black text-5xl lg:text-6xl mb-2">8,000 <span className="text-2xl">m²</span></div>
                  <div className="text-white font-black text-xs uppercase tracking-[0.3em]">Factory Floor Area</div>
                </div>
              </motion.div>
            </div>
          </div>

          {/* Challenges Section */}
          <div className="relative mb-32">
            <div className="mobile-subtitle-container">
              <SectionHeading subtitle="The Challenge" title="Mitigating Manufacturing Inefficiencies" centered />
            </div>
            <div className="grid md:grid-cols-3 gap-8 relative z-10">
              {[
                {
                  title: 'Disintegrated Manufacturing',
                  icon: <AlertTriangle className="w-8 h-8" />,
                  points: ['Lack Of Quality Ownership', 'High Logistics Overheads', 'High Lead Times'],
                  solutions: ['Finished Component Manufacturing', 'Complete Quality Ownership', 'Quick Turnaround'],
                  solutionTitle: 'Integrated Manufacturing'
                },
                {
                  title: 'Man Oriented Processes',
                  icon: <AlertTriangle className="w-8 h-8" />,
                  points: ['Inconsistent Quality', 'Unsafe Environment', 'Asymmetric Work'],
                  solutions: ['Standard Quality Management', 'Enhanced Traceability', 'Total Transparency'],
                  solutionTitle: 'Systematic Approach'
                },
                {
                  title: 'Lack of Automation',
                  icon: <AlertTriangle className="w-8 h-8" />,
                  points: ['Higher Overheads', 'Lack of Parameter Control', 'Output Variation'],
                  solutions: ['Reduced Overheads', 'Controlled Parameters', 'Improved Safety'],
                  solutionTitle: 'Automation'
                }
              ].map((item, idx) => (
                <div key={item.title} className="flex flex-col items-center">
                  <div className="p-8 bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-[2.5rem] w-full text-center mb-6">
                    <div className="text-brand-orange mb-4 flex justify-center">{item.icon}</div>
                    <h5 className="text-lg font-bold text-zinc-950 dark:text-white mb-4">{item.title}</h5>
                    <ul className="space-y-2">
                      {item.points.map(p => <li key={p} className="text-zinc-500 text-xs uppercase tracking-tighter">{p}</li>)}
                    </ul>
                  </div>

                  <ArrowDown className="text-brand-orange mb-6 w-6 h-6" />

                  <div className="p-8 bg-zinc-50 dark:bg-zinc-900 border border-brand-orange/20 dark:border-brand-orange/10 rounded-[2.5rem] w-full text-center">
                    <div className="text-brand-orange mb-4 flex justify-center"><CheckCircle2 className="w-8 h-8" /></div>
                    <h5 className="text-lg font-bold text-zinc-950 dark:text-white mb-4">{item.solutionTitle}</h5>
                    <ul className="space-y-2">
                      {item.solutions.map(s => <li key={s} className="text-zinc-500 text-xs font-bold uppercase tracking-tighter">{s}</li>)}
                    </ul>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </>
  );
};

export default About;
