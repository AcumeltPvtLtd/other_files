import React, { useRef, useState, useEffect, useCallback } from 'react';
import { motion, useMotionValue, useAnimationFrame, AnimatePresence } from 'framer-motion';
import {
  Cpu, Zap, Wind, Settings, Droplets, Layers, Flame,
  CheckCircle2, ShieldCheck, X, ChevronLeft, ChevronRight, Maximize2
} from 'lucide-react';
import { SectionHeading } from '../components/Layout';

// ----------------------------------------------------------------------
// GitHub raw content base URL
// ----------------------------------------------------------------------
const GITHUB_RAW_BASE = 'https://raw.githubusercontent.com/AcumeltPvtLtd/website_images_and_media/main';

// ----------------------------------------------------------------------
// Utility: get industrial images for each item (GitHub raw URLs + external)
// ----------------------------------------------------------------------
const getItemImages = (item: any) => {
  const mapping: Record<string, string[]> = {
    // Foundry infrastructure
    'Core Making': [
      `${GITHUB_RAW_BASE}/core_shop/0a620900-ae85-4e74-aa3e-b903c11d1be9.jpg`,
      `${GITHUB_RAW_BASE}/core_shop/4af6fef2-8af8-4f3d-a7ce-f33671622e1c.jpg`,
      `${GITHUB_RAW_BASE}/core_shop/5a318d83-cb59-4e48-9561-86270e3fbe6a.jpg`,
    ],
    'Sand Plant': [
      // No additional media; only the primary image is used.
    ],
    'Molding Line': [
      `${GITHUB_RAW_BASE}/molding_line/molding-image-1-1024x906.webp`,
    ],
    'Melting System': [
      `${GITHUB_RAW_BASE}/melting/11.jpg`,
      `${GITHUB_RAW_BASE}/melting/12.jpg`,
      `${GITHUB_RAW_BASE}/melting/melting-image-01.webp`,
      `${GITHUB_RAW_BASE}/melting/unnamed.jpg`,
      `${GITHUB_RAW_BASE}/melting/unnamed.webp`,
    ],
    'Pouring System': [
      `${GITHUB_RAW_BASE}/pouring/1.jpeg`,
      `${GITHUB_RAW_BASE}/pouring/3.jpeg`,
      `${GITHUB_RAW_BASE}/pouring/47d80254-4ea3-4757-9dfe-b9ce9c3b9142.jpg`,
      `${GITHUB_RAW_BASE}/pouring/6.jpeg`,
      `${GITHUB_RAW_BASE}/pouring/70358.jpeg`,
      `${GITHUB_RAW_BASE}/pouring/70370.jpeg`,
      `${GITHUB_RAW_BASE}/pouring/804438f1-ad2c-4d95-9a73-86a035cc14b9.jpg`,
      `${GITHUB_RAW_BASE}/pouring/d9b7e638-e610-4e40-b974-ac61c60e94d0.jpg`,
      `${GITHUB_RAW_BASE}/pouring/fd2c86d7-4680-451d-afe0-1210222d2133.jpg`,
      `${GITHUB_RAW_BASE}/pouring/pauring-system-image-1-768x679.webp`,
    ],
    'Shotblasting': [
      `${GITHUB_RAW_BASE}/shot_blasting/70331.jpeg`,
      `${GITHUB_RAW_BASE}/shot_blasting/shot_blasting.jpg`,
    ],
    'Automatic Fettling': [
      `${GITHUB_RAW_BASE}/fettling_machine/unnamed.webp`,
      `${GITHUB_RAW_BASE}/fettling_machine/v1.mp4`,
    ],
    // Machine shop
    'Vertical Turning Lathe (VTL)': [
      `${GITHUB_RAW_BASE}/machine_shop/VTL/70375.jpeg`,
    ],
    'CNC Turning Lathe': [
      `${GITHUB_RAW_BASE}/machine_shop/CNC/70377.jpeg`,
    ],
    'Vertical Machining Center (VMC)': [
      `${GITHUB_RAW_BASE}/machine_shop/VMC/70376.jpeg`,
    ],
    // Special processes
    'Paint Shop': [
      `${GITHUB_RAW_BASE}/paint_shop/17fea983-9f6f-4499-b28f-0124bd349ee9.jpg`,
      `${GITHUB_RAW_BASE}/paint_shop/21c23c95-bbe5-489b-af0c-17847f32ae10.jpg`,
      `${GITHUB_RAW_BASE}/paint_shop/23238dec-bd6f-45f7-918d-f577ea413946.jpg`,
      `${GITHUB_RAW_BASE}/paint_shop/354467de-d770-4d97-b8bd-6b3a0ce6a967.jpg`,
      `${GITHUB_RAW_BASE}/paint_shop/ba04a35f-6783-4dad-836f-8a2d7b29f3d6.jpg`,
      `${GITHUB_RAW_BASE}/paint_shop/d37cb9c9-a85a-4a93-8c83-af2ecd41417e.jpg`,
      `${GITHUB_RAW_BASE}/paint_shop/e23fdfbd-566d-4ab1-bdf9-7971afd654a4.jpg`,
    ],
    'Heat Treatment': [
      // No additional media
    ],
    // Sustainable Manufacturing – no media
    'Dust Extraction': [],
    'Fume Extraction': [],
    'Metallic Dust Extraction': [],
    'Sewage Treatment Plant': [],
    'Effluent Treatment Plant': [],
    'Corporate Social Responsibility': [],
  };

  const images = mapping[item.title];
  if (images && images.length > 0) {
    return images;
  }

  // Fallback to root images (only for items not explicitly listed above)
  return [
    `${GITHUB_RAW_BASE}/plant.jpeg`,
    `${GITHUB_RAW_BASE}/plan2.jpeg`,
    `${GITHUB_RAW_BASE}/70328.jpeg`,
  ];
};

// ----------------------------------------------------------------------
// Lightbox Component
// ----------------------------------------------------------------------
const MediaLightbox = ({ isOpen, mediaList, currentMedia, currentIndex, onClose, onNext, onPrev }: any) => {
  if (!isOpen) return null;
  const isVideo = currentMedia && currentMedia.endsWith('.mp4');

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black/95 backdrop-blur-lg"
      onClick={onClose}
    >
      <div className="relative w-full h-full flex items-center justify-center pointer-events-none">
        <button
          onClick={(e) => { e.stopPropagation(); onPrev(); }}
          className="absolute left-4 md:left-8 z-20 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all backdrop-blur-md pointer-events-auto border border-white/10"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>

        <div className="relative max-w-[90vw] max-h-[90vh] pointer-events-auto">
          {isVideo ? (
            <video
              src={currentMedia}
              autoPlay
              muted
              loop
              playsInline
              controls
              className="max-w-full max-h-[90vh] object-contain rounded-lg shadow-2xl"
            />
          ) : (
            <img
              src={currentMedia}
              alt="Lightbox media"
              className="max-w-full max-h-[90vh] object-contain rounded-lg shadow-2xl"
            />
          )}
        </div>

        <button
          onClick={(e) => { e.stopPropagation(); onNext(); }}
          className="absolute right-4 md:right-8 z-20 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all backdrop-blur-md pointer-events-auto border border-white/10"
        >
          <ChevronRight className="w-6 h-6" />
        </button>

        <button
          onClick={(e) => { e.stopPropagation(); onClose(); }}
          className="absolute top-4 right-4 md:top-8 md:right-8 z-20 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all backdrop-blur-md pointer-events-auto border border-white/10"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 bg-black/60 backdrop-blur-md px-4 py-2 rounded-full text-white text-sm font-mono pointer-events-auto">
          {currentIndex + 1} / {mediaList.length}
        </div>
      </div>
    </motion.div>
  );
};

// ----------------------------------------------------------------------
// Detail Modal Component (Media Hub)
// ----------------------------------------------------------------------
const DetailModal = ({ item, currentIndex, totalItems, onNext, onPrev, onClose, hideText, onOpenLightbox }: any) => {
  if (!item) return null;

  const hasSpecs = 'specs' in item && Array.isArray(item.specs);
  const hasFeatures = 'features' in item && Array.isArray(item.features);
  const hasDesc = 'desc' in item;
  const images = getItemImages(item);
  const hasMedia = item.video || images.length > 0;

  const handleMediaClick = (mediaUrl: string, e: React.MouseEvent) => {
    e.stopPropagation();
    onOpenLightbox(item, mediaUrl);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl"
      onClick={onClose}
    >
      <div className="relative flex items-center justify-center w-full max-w-6xl h-full pointer-events-none">
        {/* Navigation - Previous */}
        <button
          onClick={(e) => { e.stopPropagation(); onPrev(); }}
          className="absolute left-0 lg:-left-12 z-30 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all backdrop-blur-md pointer-events-auto border border-white/10 hidden md:block"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>

        <motion.div
          key={item.title}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="relative max-w-4xl w-full max-h-[90vh] overflow-y-auto bg-white dark:bg-zinc-950 rounded-[2rem] shadow-2xl border border-zinc-200 dark:border-zinc-800 pointer-events-auto"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Internal Navigation Controls for Mobile */}
          <div className="sticky top-0 right-0 flex justify-between items-center p-3 z-30 md:p-4 pointer-events-none">
            <div className="flex items-center gap-2 pointer-events-auto bg-black/60 backdrop-blur-md py-1 px-3 rounded-full border border-white/10 text-white/90">
              <span className="text-[9px] font-black uppercase tracking-wider">Item {currentIndex + 1} / {totalItems}</span>
            </div>
            <div className="flex gap-2 pointer-events-auto">
              <button
                onClick={(e) => { e.stopPropagation(); onPrev(); }}
                className="p-2 rounded-full bg-black/60 backdrop-blur-md hover:bg-black/80 text-white transition-all md:hidden border border-white/10"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={(e) => { e.stopPropagation(); onNext(); }}
                className="p-2 rounded-full bg-black/60 backdrop-blur-md hover:bg-black/80 text-white transition-all md:hidden border border-white/10"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
              <button
                onClick={onClose}
                className="p-2 rounded-full bg-brand-orange hover:scale-110 text-white transition-all shadow-lg border border-orange-400/20"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="px-6 pb-10 pt-2 md:px-10 md:pb-12">
            {hasMedia && (
              <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-8">
                <div className="md:col-span-3 relative aspect-video rounded-2xl overflow-hidden bg-zinc-900 shadow-lg border border-zinc-800 cursor-pointer group">
                  {item.video && (
                    <div onClick={(e) => handleMediaClick(item.video, e)} className="w-full h-full">
                      {item.video.endsWith('.mp4') ? (
                        <video
                          src={item.video}
                          autoPlay
                          muted
                          loop
                          playsInline
                          key={item.video}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <img
                          src={item.video}
                          alt={item.title}
                          className="w-full h-full object-cover"
                        />
                      )}
                      <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
                        <div className="bg-black/60 rounded-full p-2">
                          <Maximize2 className="w-5 h-5 text-white" />
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                <div className="md:col-span-2 grid grid-cols-2 gap-3">
                  {images.map((img: string, idx: number) => (
                    <div
                      key={idx}
                      className={`rounded-xl overflow-hidden bg-zinc-800 shadow-md cursor-pointer group ${idx === 0 ? 'col-span-2 aspect-[2/1]' : 'aspect-square'}`}
                      onClick={(e) => handleMediaClick(img, e)}
                    >
                      {img.endsWith('.mp4') ? (
                        <video
                          src={img}
                          autoPlay
                          muted
                          loop
                          playsInline
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <img
                          src={img}
                          alt={`${item.title} ${idx + 1}`}
                          className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-500"
                        />
                      )}
                      <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
                        <div className="bg-black/60 rounded-full p-1.5">
                          <Maximize2 className="w-3 h-3 text-white" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {!hideText && (
              <>
                <div className="flex items-start gap-4 mb-6">
                  <div className="text-brand-orange bg-brand-orange/10 p-3 rounded-xl shrink-0">
                    {React.cloneElement(item.icon as React.ReactElement, { className: "w-7 h-7" })}
                  </div>
                  <div>
                    <h2 className="text-xl md:text-1xl font-black dark:text-white leading-tight mb-1">{item.title}</h2>
                    {item.subtitle && (
                      <p className="text-zinc-500 text-[10px] font-black uppercase tracking-[0.2em] opacity-80">
                        {item.subtitle}
                      </p>
                    )}
                  </div>
                </div>

                {hasDesc && <p className="text-base text-zinc-600 dark:text-zinc-400 mb-8 leading-relaxed font-medium">{item.desc}</p>}

                {hasSpecs && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-zinc-50 dark:bg-zinc-900/50 p-6 rounded-[1.5rem] border border-zinc-200 dark:border-zinc-800 mb-8">
                    {item.specs.map((spec: any, idx: number) => (
                      <div key={idx} className="flex flex-col border-l-2 border-brand-orange/40 pl-4">
                        <p className="text-[10px] text-zinc-500 font-black uppercase tracking-wider mb-0.5">{spec.label}</p>
                        <p className="text-sm font-bold dark:text-zinc-200">{spec.value}</p>
                      </div>
                    ))}
                  </div>
                )}

                {hasFeatures && (
                  <div className="space-y-3">
                    <p className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-400 mb-4">Capabilities & Compliance</p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {item.features.map((feature: string, idx: number) => (
                        <motion.div
                          key={idx}
                          initial={{ opacity: 0, y: 5 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: idx * 0.04 }}
                          className="flex items-center gap-3 text-xs font-bold dark:text-zinc-300 bg-white dark:bg-zinc-900/80 p-3 rounded-xl border border-zinc-200 dark:border-zinc-800 shadow-sm"
                        >
                          <CheckCircle2 className="w-4 h-4 text-brand-orange shrink-0" />
                          <span>{feature}</span>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        </motion.div>

        {/* Navigation - Next */}
        <button
          onClick={(e) => { e.stopPropagation(); onNext(); }}
          className="absolute right-0 lg:-right-12 z-30 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all backdrop-blur-md pointer-events-auto border border-white/10 hidden md:block"
        >
          <ChevronRight className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};

// ----------------------------------------------------------------------
// Infinite Slider
// ----------------------------------------------------------------------
const InfiniteSlider = ({ items, renderCard, baseSpeed = 1, isPaused, onTogglePause, onItemClick }: any) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const x = useMotionValue(0);
  const [isDragging, setIsDragging] = useState(false);
  const [contentWidth, setContentWidth] = useState(0);
  const justDragged = useRef(false);

  const duplicatedItems = [...items, ...items, ...items];

  useEffect(() => {
    if (contentRef.current) setContentWidth(contentRef.current.scrollWidth / 3);
  }, [items]);

  useAnimationFrame((_, delta) => {
    if (isPaused || isDragging || contentWidth === 0) return;
    const deltaMove = baseSpeed * (delta / 10);
    let newX = x.get() - deltaMove;
    newX = ((newX % contentWidth) + contentWidth) % contentWidth - contentWidth;
    x.set(newX);
  });

  const handleDragStart = () => { setIsDragging(true); justDragged.current = true; };
  const handleDragEnd = () => { setIsDragging(false); setTimeout(() => { justDragged.current = false; }, 100); };

  const handleContainerClick = () => {
    if (!justDragged.current) onTogglePause();
  };

  return (
    <div
      ref={containerRef}
      className="relative overflow-hidden py-10 cursor-grab active:cursor-grabbing"
      onClick={handleContainerClick}
    >
      <motion.div
        ref={contentRef}
        className={`flex gap-8 ${isDragging ? 'pointer-events-none' : ''}`}
        style={{ x }}
        drag="x"
        onDragStart={handleDragStart}
        onDragEnd={handleDragEnd}
        dragElastic={0.05}
        dragMomentum={false}
      >
        {duplicatedItems.map((item, idx) => (
          <div key={idx} className="flex-shrink-0 w-[85vw] md:w-[500px] select-none">
            {renderCard(item, (it: any) => onItemClick(it, items))}
          </div>
        ))}
      </motion.div>
    </div>
  );
};

// ----------------------------------------------------------------------
// Main Component
// ----------------------------------------------------------------------
const Infrastructure = () => {
  const equipment = [
    {
      title: 'Core Making',
      subtitle: 'Galaxy Machines & Core Dryer',
      icon: <Layers className="w-8 h-8" />,
      video: `${GITHUB_RAW_BASE}/core_shop/core_shop1.jpeg`,
      specs: [
        { label: 'Process', value: 'Cold Box Process' },
        { label: 'Machine Capacity', value: '10 Liters: Vertical & Horizontal' },
        { label: 'Core Dryer', value: 'Microwave Oven Core Dryer' },
        { label: 'Coating', value: 'Water/Alcohol Based' }
      ]
    },
    {
      title: 'Sand Plant',
      subtitle: 'Savelli Intensive Mixer',
      icon: <Droplets className="w-8 h-8" />,
      video: `${GITHUB_RAW_BASE}/sand_plant/Sand-plant-image-1-768x679.webp`,
      specs: [
        { label: 'Capacity', value: '24 Metric Tonne Per Hour' },
        { label: 'Mixer', value: 'Savelli Intensive Mixer' },
        { label: 'Cooling', value: 'Savelli Multicooler' },
        { label: 'Rejection Control', value: 'Online Sand Testing With Batch Correction' },
        { label: 'Operation Control', value: 'SCADA Control And Monitoring' },
        { label: 'Storage', value: '100 Metric Tonne Silo' }
      ]
    },
    {
      title: 'Molding Line',
      subtitle: 'Sinto FBO III A(N)',
      icon: <Cpu className="w-8 h-8" />,
      video: `${GITHUB_RAW_BASE}/molding_line/WhatsApp_Video%202026-03-25%20at%203.16.10%20PM.mp4`,
      specs: [
        { label: 'Molding Method', value: 'High Pressure Flaskless Molding' },
        { label: 'Mold Size', value: '508 x 660 x 180-250 / 180-250 mm' },
        { label: 'Output', value: '120 Molds Per Hour' },
        { label: 'Max Pouring Weight', value: '50 Kilograms' }
      ]
    },
    {
      title: 'Melting System',
      subtitle: 'Inductotherm Duraline Tritrack Furnace',
      icon: <Zap className="w-8 h-8" />,
      video: `${GITHUB_RAW_BASE}/melting/1.jpeg`,
      specs: [
        { label: 'Type', value: 'Medium Frequency Induction Melting' },
        { label: 'Converter', value: 'IGBT Converter' },
        { label: 'Crucible Capacity', value: '500 Kilograms (3 Independently Powered)' },
        { label: 'Converter Capacity', value: '1650 Kilowatts' },
        { label: 'Inverter Capacity', value: '550 Kilowatts each' },
        { label: 'Melting Capacity', value: '2.5 Metric Tons Per Hour' },
        { label: 'Features', value: 'Auto-sintering Cycles' }
      ]
    },
    {
      title: 'Pouring System',
      subtitle: 'Shree Shakti Smart Autopour APS 500',
      icon: <Settings className="w-8 h-8" />,
      video: `${GITHUB_RAW_BASE}/pouring/70349.mp4`,
      specs: [
        { label: 'Capacity', value: '500 Kilograms' },
        { label: 'Control', value: '4 Axis CNC & Weight Control' },
        { label: 'Inoculation', value: 'Weight Controlled In‑Stream Auto Inoculation' }
      ]
    },
    {
      title: 'Shotblasting',
      subtitle: 'Gostol TST VKP 1200x1600',
      icon: <ShieldCheck className="w-8 h-8" />,
      video: `${GITHUB_RAW_BASE}/shot_blasting/67d0a815-d9c4-45ef-9d2d-f2e1ee0e714b.jpg`,
      specs: [
        { label: 'Type', value: 'Continuous Overhead Rail, Y‑Type' },
        { label: 'Hanger Capacity', value: '1 Metric Ton Each' },
        { label: 'Abrasive Speed', value: '80 Meters Per Second' },
        { label: 'Abrasive Flow', value: '270 Kg Per Minute' }
      ]
    },
    {
      title: 'Automatic Fettling',
      subtitle: 'High‑Speed Precision',
      icon: <Settings className="w-8 h-8" />,
      video: `${GITHUB_RAW_BASE}/fettling_machine/random.mp4`,
      specs: [
        { label: 'Process', value: 'Automatic Grinding & Finishing' },
        { label: 'Consistency', value: 'High Dimensional Accuracy' },
        { label: 'Surface Finish', value: 'Superior & Uniform' },
        { label: 'Batch Control', value: 'Automated Cycle Management' }
      ]
    }
  ];

  const machines = [
    {
      title: 'Vertical Turning Lathe (VTL)',
      subtitle: 'Vertical Turning',
      icon: <Settings className="w-8 h-8" />,
      video: `${GITHUB_RAW_BASE}/machine_shop/VTL/shaping_cast_iron_by_cnc.mp4`,
      specs: [
        { label: 'Max Turning Dia', value: '700 Millimeters' },
        { label: 'Max Turning Height', value: '700 Millimeters' }
      ]
    },
    {
      title: 'CNC Turning Lathe',
      subtitle: 'Horizontal Turning',
      icon: <Cpu className="w-8 h-8" />,
      video: `${GITHUB_RAW_BASE}/machine_shop/CNC/Cast_iron_face_on_lathe.mp4`,
      specs: [
        { label: 'Max Turning Dia', value: '250 Millimeters' },
        { label: 'Max Turning Length', value: '350 Millimeters' }
      ]
    },
    {
      title: 'Vertical Machining Center (VMC)',
      subtitle: 'Multi‑Axis Milling',
      icon: <Settings className="w-8 h-8" />,
      video: `${GITHUB_RAW_BASE}/machine_shop/VMC/Doosan_DNM_500_II_.mp4`,
      specs: [
        { label: 'X‑Axis Travel', value: '1000 Millimeters' },
        { label: 'Y‑Axis Travel', value: '600 Millimeters' },
        { label: 'Z‑Axis Travel', value: '600 Millimeters' },
        { label: 'Additional Capabilities', value: '4th Axis Rotary Table' }
      ]
    }
  ];

  const treatments = [
    {
      title: 'Paint Shop',
      subtitle: 'Surface Treatment',
      icon: <Droplets className="w-10 h-10" />,
      video: `${GITHUB_RAW_BASE}/paint_shop/0b83ca38-e603-45c2-b379-a65cfd53dbd2.jpg`,
      desc: 'Multi‑stage automated paint process including degreasing, phosphating, and high‑quality liquid painting to ensure superior corrosion resistance.',
      features: [
        '7‑Tank Spray Type Pre-Treatment Process For Surface Preparation',
        'Chrome-Free Pre-Treatment',
        'Liquid Primer & Painting Facility',
        'Automatic Powder Coating Facility',
        'Forced Drying At 100°C–200°C For Fast Drying & Durable Finish',
        'Multi-Metal Surface Treatment Capability',
        'Standards: Compiled With ISO 6005, ASTM D609, ISO 10546'
      ]
    },
    {
      title: 'Heat Treatment',
      subtitle: 'Thermal Treatment',
      icon: <Flame className="w-10 h-10" />,
      video: `${GITHUB_RAW_BASE}/heat_treatment/heat_treatment_plant.jpg`,
      desc: 'Dedicated heat treatment plant for Austempered Ductile Iron (ADI) and other specialized thermal processes to enhance mechanical properties.',
      features: [
        'Austempering',
        'Annealing & Normalizing',
        'Stress Relieving',
        'Salt Quench Furnace',
        'Minimum Quenching Temperature: 200°C',
        'Carbon Potential Control (0.8%–1.2%)',
        'SCADA Controls During Austempering & Quenching',
        'Real Time Temperature Measurement & Monitoring'
      ]
    }
  ];

  const environmental = [
    {
      title: 'Dust Extraction',
      subtitle: 'Neoairtech Systems',
      icon: <Wind className="w-6 h-6" />,
      // video property removed – no media
      features: [
        'Neoairtech Dust Extraction System With Cassette Filters',
        'Separate Filtration For Sand Plant, Multicooler & Shotblasting',
        'Guaranteed Emission: < 20 mg/Nm³',
        'IP 55 Rated Equipment For Outdoor Application',
        'BAT (Best Available Technique) Compliant'
      ]
    },
    {
      title: 'Fume Extraction',
      subtitle: 'Techflow Enterprises',
      icon: <Wind className="w-6 h-6" />,
      // video removed
      features: [
        'Bag Filtration System For Fume Treatment',
        'Guaranteed Emission: < 50 mg/m³',
        'Spark Arrestor Included To Avoid Fire Hazards',
        'Compliant With The Environment (Protection) Rules, 1986'
      ]
    },
    {
      title: 'Metallic Dust Extraction',
      subtitle: 'High-Vacuum Spark Arrestor System',
      icon: <ShieldCheck className="w-6 h-6" />,
      // video removed
      features: [
        'High-Vacuum Spark Arrestor System',
        'Heavy Metal Particulate Filtration Down To 0.5 Micron',
        'Automated Pulse-Jet Cleaning System',
        'High Density Metallic Dust Collection'
      ]
    },
    {
      title: 'Sewage Treatment Plant',
      subtitle: 'Aerobic - Anaerobic processing ',
      icon: <Droplets className="w-6 h-6" />,
      // video removed
      features: [
        'Sequential Batch Reactor (SBR) Biological Treatment',
        'Recycled Water Used For Landscaping & Gardening',
        'Sludge Dewatering & Safe Disposal'
      ]
    },
    {
      title: 'Effluent Treatment Plant',
      subtitle: 'Chemical Precipitation For Casting Wastewater',
      icon: <Droplets className="w-6 h-6" />,
      // video removed
      features: [
        'Chemical Precipitation For Painting Wastewater',
        'pH Correction & Neutralization Tanks',
        'Oil & Grease Separation',
        'Compliant With Industrial Discharge Standards',
        'Treated Water Reused In Process'
      ]
    },
    {
      title: 'Corporate Social Responsibility',
      subtitle: 'Sustainable & Ethical Operations',
      icon: <CheckCircle2 className="w-6 h-6" />,
      // video removed
      features: [
        'Sustainable Procurement Of Raw Materials',
        'Worker Housing & Food Provision',
        'Worker Welfare & Training Programs',
        'Worker Safety Excellence: Zero Lost Time Injuries',
      ]
    }
  ];

  // Navigation Logic for DetailModal
  const [modalContext, setModalContext] = useState<any>(null); // { item, section, index, hideText }
  const [userPaused, setUserPaused] = useState(false);
  const [modalPaused, setModalPaused] = useState(false);

  // Lightbox state
  const [lightboxState, setLightboxState] = useState<{
    isOpen: boolean;
    mediaList: string[];
    currentMedia: string;
    currentIndex: number;
  }>({
    isOpen: false,
    mediaList: [],
    currentMedia: '',
    currentIndex: 0,
  });

  const openLightbox = useCallback((item: any, clickedMedia: string) => {
    const mediaList = getItemImages(item);
    // Include the main video as well for full media list (if it exists and not already in mediaList)
    const fullMediaList = item.video && !mediaList.includes(item.video) ? [item.video, ...mediaList] : mediaList;
    const index = fullMediaList.findIndex(m => m === clickedMedia);
    if (index !== -1 && fullMediaList.length > 0) {
      setLightboxState({
        isOpen: true,
        mediaList: fullMediaList,
        currentMedia: clickedMedia,
        currentIndex: index,
      });
    }
  }, []);

  const closeLightbox = useCallback(() => {
    setLightboxState({
      isOpen: false,
      mediaList: [],
      currentMedia: '',
      currentIndex: 0,
    });
  }, []);

  const nextLightboxMedia = useCallback(() => {
    setLightboxState(prev => {
      if (prev.mediaList.length === 0) return prev;
      const nextIndex = (prev.currentIndex + 1) % prev.mediaList.length;
      return {
        ...prev,
        currentMedia: prev.mediaList[nextIndex],
        currentIndex: nextIndex,
      };
    });
  }, []);

  const prevLightboxMedia = useCallback(() => {
    setLightboxState(prev => {
      if (prev.mediaList.length === 0) return prev;
      const prevIndex = (prev.currentIndex - 1 + prev.mediaList.length) % prev.mediaList.length;
      return {
        ...prev,
        currentMedia: prev.mediaList[prevIndex],
        currentIndex: prevIndex,
      };
    });
  }, []);

  const openModal = useCallback((item: any, section: any[]) => {
    const idx = section.findIndex(i => i.title === item.title);
    const hideText = section === treatments; // Hide text only for treatment section
    setModalContext({ item, section, index: idx, hideText });
    setModalPaused(true);
  }, [treatments]);

  const nextModalItem = useCallback(() => {
    if (!modalContext) return;
    const { section, index, hideText } = modalContext;
    const nextIdx = (index + 1) % section.length;
    setModalContext({ ...modalContext, item: section[nextIdx], index: nextIdx, hideText });
  }, [modalContext]);

  const prevModalItem = useCallback(() => {
    if (!modalContext) return;
    const { section, index, hideText } = modalContext;
    const prevIdx = (index - 1 + section.length) % section.length;
    setModalContext({ ...modalContext, item: section[prevIdx], index: prevIdx, hideText });
  }, [modalContext]);

  const closeModal = useCallback(() => {
    setModalContext(null);
    setModalPaused(false);
  }, []);

  // Card UI Components
  const SpecCard = (item: any, onCardClick: any) => {
    const handleMediaClick = (e: React.MouseEvent) => {
      e.stopPropagation();
      if (item.video) openLightbox(item, item.video);
    };

    return (
      <div
        className="h-full bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-[2.5rem] overflow-hidden shadow-md cursor-pointer transition-all hover:scale-[1.02] hover:border-brand-orange/50 hover:shadow-xl"
        onClick={(e) => { e.stopPropagation(); onCardClick(item); }}
      >
        <div className="relative aspect-video cursor-pointer group" onClick={handleMediaClick}>
          {item.video && (
            item.video.endsWith('.mp4') ? (
              <video
                src={item.video}
                autoPlay
                muted
                loop
                playsInline
                preload="auto"
                className="w-full h-full object-cover"
              />
            ) : (
              <img
                src={item.video}
                alt={item.title}
                className="w-full h-full object-cover"
              />
            )
          )}
          <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
            <div className="bg-black/60 rounded-full p-2">
              <Maximize2 className="w-5 h-5 text-white" />
            </div>
          </div>
          <div className="absolute inset-0 bg-gradient-to-t from-zinc-50 dark:from-zinc-900 to-transparent opacity-40 pointer-events-none" />
        </div>
        <div className="p-8 text-center">
          <div className="text-brand-orange mb-4 flex justify-center">{item.icon}</div>
          <h4 className="text-lg font-bold dark:text-white">{item.title}</h4>
          <p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest mb-6">{item.subtitle}</p>
          <div className="grid grid-cols-2 gap-4">
            {item.specs.slice(0, 4).map((spec: any, i: number) => (
              <div key={i} className="border-t border-zinc-200 dark:border-zinc-800 pt-3">
                <p className="text-[9px] text-zinc-500 font-bold uppercase">{spec.label}</p>
                <p className="text-xs font-semibold dark:text-zinc-300">{spec.value}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  };

  const TreatmentCard = (item: any, onCardClick: any) => {
    const handleMediaClick = (e: React.MouseEvent) => {
      e.stopPropagation();
      if (item.video) openLightbox(item, item.video);
    };

    return (
      <div
        className="h-full bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-[2.5rem] p-8 flex flex-col md:flex-row gap-8 items-center shadow-md cursor-pointer transition-all hover:scale-[1.02] hover:border-brand-orange/50 hover:shadow-xl"
        onClick={(e) => { e.stopPropagation(); onCardClick(item, treatments); }}
      >
        <div className="w-full md:w-1/3 aspect-square rounded-2xl overflow-hidden shrink-0 cursor-pointer group" onClick={handleMediaClick}>
          {item.video && (
            item.video.endsWith('.mp4') ? (
              <video
                src={item.video}
                autoPlay
                muted
                loop
                playsInline
                className="w-full h-full object-cover"
              />
            ) : (
              <img
                src={item.video}
                alt={item.title}
                className="w-full h-full object-cover"
              />
            )
          )}
          <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
            <div className="bg-black/60 rounded-full p-2">
              <Maximize2 className="w-5 h-5 text-white" />
            </div>
          </div>
        </div>
        <div className="flex-1 text-left">
          <div className="text-brand-orange mb-3">{item.icon}</div>
          <h4 className="text-lg font-bold dark:text-white">{item.title}</h4>
          <p className="text-zinc-600 dark:text-zinc-400 text-sm my-4 leading-relaxed line-clamp-2">{item.desc}</p>
          <ul className="space-y-2">
            {item.features.map((f: string) => (
              <li key={f} className="flex items-start gap-2 text-xs font-bold dark:text-zinc-200">
                <CheckCircle2 className="w-4 h-4 text-brand-orange shrink-0" /> {f}
              </li>
            ))}
          </ul>
        </div>
      </div>
    );
  };

  const FeatureCard = (item: any, onCardClick: any) => {
    // No media area for environmental cards (video is undefined)
    const hasMedia = !!item.video;
    const handleMediaClick = (e: React.MouseEvent) => {
      e.stopPropagation();
      if (hasMedia && item.video) openLightbox(item, item.video);
    };

    return (
      <div
        className="h-full bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-[2.5rem] overflow-hidden shadow-md transition-all hover:scale-[1.02] hover:border-brand-orange/50 hover:shadow-xl"
        onClick={(e) => { e.stopPropagation(); onCardClick(item); }}
      >
        {hasMedia && (
          <div className="relative aspect-video cursor-pointer group" onClick={handleMediaClick}>
            {item.video && (
              item.video.endsWith('.mp4') ? (
                <video
                  src={item.video}
                  autoPlay
                  muted
                  loop
                  playsInline
                  className="w-full h-full object-cover"
                />
              ) : (
                <img
                  src={item.video}
                  alt={item.title}
                  className="w-full h-full object-cover"
                />
              )
            )}
            <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
              <div className="bg-black/60 rounded-full p-2">
                <Maximize2 className="w-5 h-5 text-white" />
              </div>
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-zinc-50 dark:from-zinc-900 to-transparent opacity-40 pointer-events-none" />
          </div>
        )}
        <div className="p-8">
          <div className="text-brand-orange mb-4 flex justify-center">{item.icon}</div>
          <h4 className="text-lg font-bold dark:text-white text-center">{item.title}</h4>
          <p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest text-center mb-6">{item.subtitle}</p>
          <ul className="space-y-3">
            {item.features.slice(0, 4).map((f: string, i: number) => (
              <li key={i} className="flex items-start gap-3 text-xs font-medium dark:text-zinc-300">
                <CheckCircle2 className="w-4 h-4 text-brand-orange shrink-0 mt-0.5" />
                <span className="line-clamp-1">{f}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    );
  };

  return (
    <div className="pt-32 pb-20 bg-white dark:bg-zinc-950 overflow-hidden">
      <style>{`
        @media (max-width: 768px) {
          .mobile-subtitle-container span {
            font-size: 3vw !important;
            letter-spacing: 0.2em !important;
          }
        }
      `}</style>
      <div className="container mx-auto px-6">
        <section className="mb-24">
          <div className="mobile-subtitle-container">
            <SectionHeading subtitle="Greensand casting" title="Foundry Infrastructure" centered />
          </div>
          <InfiniteSlider
            items={equipment}
            renderCard={SpecCard}
            baseSpeed={1.2}
            isPaused={userPaused || modalPaused}
            onTogglePause={() => setUserPaused(!userPaused)}
            onItemClick={openModal}
          />
        </section>

        <section className="mb-24">
          <div className="mobile-subtitle-container">
            <SectionHeading subtitle="high precision cnc machining" title="machine shop" centered />
          </div>
          <InfiniteSlider
            items={machines}
            renderCard={SpecCard}
            baseSpeed={1.5}
            isPaused={userPaused || modalPaused}
            onTogglePause={() => setUserPaused(!userPaused)}
            onItemClick={openModal}
          />
        </section>

        <section className="mb-24">
          <div className="mobile-subtitle-container">
            <SectionHeading subtitle="special processes" title="heat treatment & surface coating" centered />
          </div>
          <div className="py-10">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {treatments.map((item) => (
                <div key={item.title}>{TreatmentCard(item, openModal)}</div>
              ))}
            </div>
          </div>
        </section>

        <section className="mb-24">
          <div className="mobile-subtitle-container">
            <SectionHeading subtitle="Eco‑Friendly" title="Sustainable Manufacturing" centered />
          </div>
          <InfiniteSlider
            items={environmental}
            renderCard={FeatureCard}
            baseSpeed={0.8}
            isPaused={userPaused || modalPaused}
            onTogglePause={() => setUserPaused(!userPaused)}
            onItemClick={openModal}
          />
        </section>
      </div>

      <AnimatePresence>
        {modalContext && (
          <DetailModal
            item={modalContext.item}
            currentIndex={modalContext.index}
            totalItems={modalContext.section.length}
            onNext={nextModalItem}
            onPrev={prevModalItem}
            onClose={closeModal}
            hideText={modalContext.hideText}
            onOpenLightbox={openLightbox}
          />
        )}
        {lightboxState.isOpen && (
          <MediaLightbox
            isOpen={lightboxState.isOpen}
            mediaList={lightboxState.mediaList}
            currentMedia={lightboxState.currentMedia}
            currentIndex={lightboxState.currentIndex}
            onClose={closeLightbox}
            onNext={nextLightboxMedia}
            onPrev={prevLightboxMedia}
          />
        )}
      </AnimatePresence>
    </div>
  );
};

export default Infrastructure;
