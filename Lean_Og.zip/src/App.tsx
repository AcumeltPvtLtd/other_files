import React, { Suspense, lazy } from 'react';
import { Routes, Route } from 'react-router-dom';
import { Layout } from './components/Layout';

// Lazy load pages for better performance
const Home = lazy(() => import('./pages/Home'));
const About = lazy(() => import('./pages/About'));
const Infrastructure = lazy(() => import('./pages/Infrastructure'));
const Quality = lazy(() => import('./pages/Quality'));
const Capabilities = lazy(() => import('./pages/Capabilities'));
const Products = lazy(() => import('./pages/Products'));
const Contact = lazy(() => import('./pages/Contact'));
const Rnd = lazy(() => import('./pages/Rnd')); // New import

const Loading = () => (
  <div className="min-h-screen bg-zinc-950 flex items-center justify-center">
    <div className="relative w-24 h-24">
      <div className="absolute inset-0 border-4 border-brand-orange/20 rounded-full" />
      <div className="absolute inset-0 border-4 border-t-brand-orange rounded-full animate-spin" />
    </div>
  </div>
);

function App() {
  return (
    <Layout>
      <Suspense fallback={<Loading />}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/infrastructure" element={<Infrastructure />} />
          <Route path="/quality" element={<Quality />} />
          <Route path="/capabilities" element={<Capabilities />} />
          <Route path="/products" element={<Products />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/rnd" element={<Rnd />} /> {/* New route */}
        </Routes>
      </Suspense>
    </Layout>
  );
}

export default App;
